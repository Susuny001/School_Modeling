import math, json, struct, shutil, base64
from pathlib import Path
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont
from trimesh.transformations import rotation_matrix, translation_matrix
from shapely.geometry import Polygon, LineString, Point
from shapely.ops import triangulate
from shapely.affinity import rotate as shp_rotate, translate as shp_translate

OUT=Path(__file__).resolve().parent; OUT.mkdir(parents=True, exist_ok=True)

# Manually authored material palette after visual review of the footage. No video pixels, crops,
# sampled colors, extracted images, UV textures, or texture-like projected imagery are used.
COLORS={
 'ground':(77,91,64,255),'grass':(54,88,52,255),'grass2':(63,97,56,255),'grass_dark':(37,70,41,255),
 'path':(153,118,101,255),'path_light':(181,153,132,255),'plaza':(211,201,177,255),'plaza_light':(226,219,199,255),
 'plaza_dark':(76,76,72,255),'plaza_teal':(91,112,105,255),'plaza_joint':(158,151,137,255),'plaza_red':(137,62,58,255),'stone_warm':(204,194,171,255),'road':(76,79,76,255),'road2':(68,72,70,255),'curb':(187,184,175,255),
 'white':(229,228,216,255),'offwhite':(211,212,202,255),'cream':(228,224,207,255),'wall_warm':(220,216,202,255),'wall_cool':(216,220,213,255),
 'red':(123,40,39,255),'red2':(145,47,43,255),'roof':(43,42,39,255),'roof2':(61,59,55,255),'roof_patch':(79,68,58,255),'roof_fade':(70,67,61,255),
 'window':(103,128,130,255),'window_dark':(86,110,113,255),'glass':(91,121,124,255),'glass_roof':(91,128,127,255),'metal':(103,108,104,255),
 'dome':(211,214,208,255),'dome_dark':(108,114,113,255),'tree_trunk':(88,64,45,255),
 'tree_leaf':(43,79,43,255),'tree_leaf2':(54,91,49,255),'tree_leaf3':(69,104,56,255),
 'track':(128,54,58,255),'track_apron':(53,104,88,255),'field':(47,96,57,255),'field2':(59,111,66,255),'court':(180,169,151,255),'court_joint':(151,144,132,255),'court_line':(226,225,210,255),
 'green_metal':(63,139,88,255),'blue':(76,110,143,255),'dark':(40,42,41,255),'stone':(219,218,207,255),
 'gold':(198,160,55,255),'car_white':(208,208,199,255),'car_dark':(45,48,48,255),'car_red':(133,44,42,255),
 'brick':(139,72,65,255),'brick2':(156,84,74,255),'brick3':(119,64,59,255),'ac_body':(201,203,196,255),'ac_grill':(72,77,76,255),
 'admin_wall':(126,130,128,255),'admin_wall2':(111,115,113,255),'admin_trim':(178,181,178,255),
 'glass_blue':(92,133,142,255),'glass_light':(150,176,181,255),'glass_silver':(170,187,188,255),'flag_red':(198,32,40,255),'flagpole':(220,224,225,255),
 'admin_light':(151,155,153,255),'admin_pale':(205,207,203,255),'admin_column':(181,143,132,255),'north_gray':(154,158,156,255),'north_gray2':(137,143,141,255),'north_roof':(188,191,186,255),'north_core':(169,87,68,255),'stadium_gray':(168,174,174,255),'stadium_pale':(224,224,218,255),'stadium_step':(191,193,187,255),'mountain':(61,87,62,255),'mountain2':(72,100,68,255),'urban':(181,185,181,255),'urban_dark':(126,133,134,255),'tile_red_dark':(101,55,47,255)
}

class Builder:
    def __init__(self): self.groups={}; self.counts={}; self.active_transform=np.eye(4)
    def set_transform(self, M=None): self.active_transform=np.eye(4) if M is None else np.asarray(M,float)
    def reset_transform(self): self.active_transform=np.eye(4)
    def add(self,mesh,key,transform=None):
        if mesh is None or len(mesh.faces)==0:return
        mesh=mesh.copy()
        T=self.active_transform if transform is None else self.active_transform@transform
        if not np.allclose(T,np.eye(4)): mesh.apply_transform(T)
        self.groups.setdefault(key,[]).append(mesh); self.counts[key]=self.counts.get(key,0)+1
    def box(self,extents,center,key,rotz=0,rotx=0,roty=0):
        m=trimesh.creation.box(extents=extents); T=translation_matrix(center)
        if rotz:T=T@rotation_matrix(math.radians(rotz),[0,0,1])
        if roty:T=T@rotation_matrix(math.radians(roty),[0,1,0])
        if rotx:T=T@rotation_matrix(math.radians(rotx),[1,0,0])
        self.add(m,key,T)
    def cyl(self,radius,height,center,key,sections=24,rotz=0,rotx=0,roty=0):
        m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections); T=translation_matrix(center)
        if rotz:T=T@rotation_matrix(math.radians(rotz),[0,0,1])
        if roty:T=T@rotation_matrix(math.radians(roty),[0,1,0])
        if rotx:T=T@rotation_matrix(math.radians(rotx),[1,0,0])
        self.add(m,key,T)
    def sphere(self,radius,center,key,subdivisions=1,scale=(1,1,1)):
        m=trimesh.creation.icosphere(subdivisions=subdivisions,radius=radius); S=np.eye(4);S[0,0],S[1,1],S[2,2]=scale
        self.add(m,key,translation_matrix(center)@S)
    def extrude(self,poly,height,z,key):
        if not poly.is_valid: poly=poly.buffer(0)
        if poly.is_empty:return
        tris=[]; geoms=list(poly.geoms) if poly.geom_type=='MultiPolygon' else [poly]
        for g in geoms:
            for t in triangulate(g):
                if g.covers(t.representative_point()):tris.append(t)
        if not tris:return
        vmap={}; verts=[]; faces=[]
        def vid(pt):
            k=(round(pt[0],8),round(pt[1],8))
            if k not in vmap:vmap[k]=len(verts);verts.append([pt[0],pt[1]])
            return vmap[k]
        for t in tris:
            c=list(t.exterior.coords)[:3];faces.append([vid(x) for x in c])
        try:m=trimesh.creation.extrude_triangulation(np.asarray(verts,float),np.asarray(faces,int),height=height)
        except Exception:return
        m.apply_translation((0,0,z));self.add(m,key)
    def cylinder_between(self,a,b,r,key,sections=8):
        a=np.array(a,float);b=np.array(b,float);v=b-a;L=np.linalg.norm(v)
        if L<1e-8:return
        m=trimesh.creation.cylinder(radius=r,height=L,sections=sections);d=v/L;z=np.array([0.,0.,1.]);axis=np.cross(z,d);dot=float(np.clip(np.dot(z,d),-1,1))
        T=translation_matrix((a+b)/2)
        if np.linalg.norm(axis)>1e-8:T=T@rotation_matrix(math.acos(dot),axis)
        elif dot<0:T=T@rotation_matrix(math.pi,[1,0,0])
        self.add(m,key,T)
    def finalize(self):
        scene=trimesh.Scene(); stats={}
        for key,arr in self.groups.items():
            m=arr[0] if len(arr)==1 else trimesh.util.concatenate(arr)
            rgba=COLORS[key]
            metallic = 0.92 if key=='flagpole' else (0.18 if key in ('metal','green_metal','glass','glass_blue','glass_light','glass_silver') else 0.0)
            roughness = 0.16 if key=='flagpole' else (0.30 if key in ('glass','glass_blue','glass_light','glass_silver','window','window_dark') else 0.74)
            mat=trimesh.visual.material.PBRMaterial(name=key,baseColorFactor=[c/255 for c in rgba],metallicFactor=metallic,roughnessFactor=roughness)
            m.visual=trimesh.visual.TextureVisuals(material=mat)
            scene.add_geometry(m,node_name=key,geom_name=key)
            stats[key]={'parts':len(arr),'vertices':int(len(m.vertices)),'faces':int(len(m.faces))}
        return scene,stats
b=Builder()

# Geometry-only lettering helper. Characters are rasterized only as a temporary construction mask;
# every visible pixel run becomes an actual thin box in the final GLB. The mask itself is never exported,
# referenced, projected, or stored as a texture/image.
def add_bitmap_text_yz(text, x, y_center, z_center, width, height, key='gold', depth=.10, font_px=76, bold=True):
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc' if bold else '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    try: font=ImageFont.truetype(font_path,font_px)
    except Exception: return
    # Large mask gives recognizable Chinese strokes while row-run merging keeps part count manageable.
    box=font.getbbox(text); tw=max(1,box[2]-box[0]); th=max(1,box[3]-box[1])
    pad=6; im=Image.new('L',(tw+pad*2,th+pad*2),0); dr=ImageDraw.Draw(im)
    dr.text((pad-box[0],pad-box[1]),text,font=font,fill=255,stroke_width=0)
    arr=np.asarray(im)>110
    ys,xs=np.where(arr)
    if len(xs)==0:return
    xmin,xmax,ymin,ymax=xs.min(),xs.max(),ys.min(),ys.max()
    arr=arr[ymin:ymax+1,xmin:xmax+1]
    H,W=arr.shape; py=width/W; pz=height/H
    # run-length merge each scan line into physical solids; plane is Y-Z at constant X.
    for r,row in enumerate(arr):
        c=0
        while c<W:
            if not row[c]: c+=1; continue
            c0=c
            while c<W and row[c]: c+=1
            run=c-c0
            yy=y_center+width/2-(c0+run/2)*py
            zz=z_center+height/2-(r+.5)*pz
            b.box((depth,max(.025,run*py),max(.025,pz*1.08)),(x,yy,zz),key)

def add_bitmap_text_xz(text, y, x_center, z_center, width, height, key='white', depth=.10, font_px=72, bold=True):
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc' if bold else '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    try: font=ImageFont.truetype(font_path,font_px)
    except Exception:return
    box=font.getbbox(text); tw=max(1,box[2]-box[0]); th=max(1,box[3]-box[1]); pad=5
    im=Image.new('L',(tw+pad*2,th+pad*2),0);dr=ImageDraw.Draw(im);dr.text((pad-box[0],pad-box[1]),text,font=font,fill=255)
    arr=np.asarray(im)>110; ys,xs=np.where(arr)
    if len(xs)==0:return
    arr=arr[ys.min():ys.max()+1,xs.min():xs.max()+1];H,W=arr.shape;px=width/W;pz=height/H
    for r,row in enumerate(arr):
        c=0
        while c<W:
            if not row[c]:c+=1;continue
            c0=c
            while c<W and row[c]:c+=1
            run=c-c0;xx=x_center-width/2+(c0+run/2)*px;zz=z_center+height/2-(r+.5)*pz
            b.box((max(.025,run*px),depth,max(.025,pz*1.08)),(xx,y,zz),key)

def sector_polygon(r0,r1,a0,a1,n=80,center=(0,0)):
    aa=np.linspace(math.radians(a0),math.radians(a1),n)
    outer=[(center[0]+r1*math.cos(a),center[1]+r1*math.sin(a)) for a in aa]
    inner=[(center[0]+r0*math.cos(a),center[1]+r0*math.sin(a)) for a in aa[::-1]]
    return Polygon(outer+inner)
def ellipse_poly(cx,cy,rx,ry,n=140): return Polygon([(cx+rx*math.cos(t),cy+ry*math.sin(t)) for t in np.linspace(0,2*math.pi,n,endpoint=False)])
def ring(r0,r1,z,key,h=.10,segments=128,center=(0,0)):
    m=trimesh.creation.annulus(r_min=r0,r_max=r1,height=h,sections=segments);m.apply_translation((center[0],center[1],z+h/2));b.add(m,key)

def gable_roof(cx,cy,L,W,z,rotz,key='red2',rise=None):
    rise=rise if rise is not None else W*.34
    v=np.array([[-L/2,-W/2,0],[L/2,-W/2,0],[L/2,W/2,0],[-L/2,W/2,0],[-L/2,0,rise],[L/2,0,rise]],float)
    f=np.array([[0,1,5],[0,5,4],[3,4,5],[3,5,2],[0,4,3],[1,2,5]])
    m=trimesh.Trimesh(v,f,process=False); b.add(m,key,translation_matrix((cx,cy,z))@rotation_matrix(math.radians(rotz),[0,0,1]))

def add_tree(x,y,scale=1.0,variant=0):
    # Mature source trees need a readable trunk/branch silhouette and a layered crown rather than
    # the faceted five-blob proxy used before V164. Everything here is actual geometry.
    th=3.55*scale
    b.cyl(.22*scale,th,(x,y,th/2),'tree_trunk',sections=14)
    # primary fork visible through gaps in the crown; deterministic variants avoid cloned silhouettes.
    forks=[(-.95,.35,.72),(.82,.55,.84),(.18,-.92,.76)]
    for i,(ox,oy,zz) in enumerate(forks):
        a=(x,y,th*.72)
        c=(x+ox*scale,y+oy*scale,th+zz*scale)
        b.cylinder_between(a,c,.105*scale,'tree_trunk',sections=10)
        # short secondary limb, angled differently by tree variant.
        turn=(-1 if (i+variant)%2 else 1)
        d=(c[0]+turn*.48*scale,c[1]+(.28 if i!=1 else -.34)*scale,c[2]+.52*scale)
        b.cylinder_between(c,d,.062*scale,'tree_trunk',sections=8)
    offs=[
      (0,0,1.62,1.12,1.02,.86),(1.10,.10,1.30,.92,.84,.80),(-.90,.72,1.15,.90,.92,.78),
      (.34,-1.00,1.12,.86,.92,.76),(-.36,-.44,2.10,.88,.84,.82),(.72,.72,2.00,.72,.78,.72),
      (-.72,-.70,1.86,.72,.76,.70),(.10,.78,2.42,.62,.68,.66)
    ]
    for k,(ox,oy,oz,sx,sy,sz) in enumerate(offs):
        key=('tree_leaf','tree_leaf2','tree_leaf3')[(k+variant)%3]
        # subdivision=2 removes the obvious icosahedral silhouette while preserving a manageable file size.
        b.sphere(1.48*scale,(x+ox*scale,y+oy*scale,th+oz*scale),key,subdivisions=2,scale=(sx,sy,sz))

def add_poplar(x,y,scale=1.0,variant=0):
    """Tall narrow poplar seen in perimeter rows and science/garden footage; stacked lobes are solid geometry."""
    h=7.8*scale
    b.cyl(.17*scale,4.0*scale,(x,y,2.0*scale),'tree_trunk',sections=12)
    for i,(zz,rad,stretch) in enumerate([(3.7,1.18,1.65),(5.0,1.28,1.85),(6.3,1.14,1.70),(7.5,.82,1.48)]):
        key=('tree_leaf','tree_leaf2','tree_leaf3')[(i+variant)%3]
        b.sphere(rad*scale,(x+(i%2-.5)*.22*scale,y+((i+1)%2-.5)*.18*scale,zz*scale),key,subdivisions=2,scale=(.72,.72,stretch))

def add_conifer(x,y,scale=1.0,variant=0):
    """Layered evergreen/conifer with visible trunk and tapered whorls; no billboard or texture."""
    b.cyl(.18*scale,5.8*scale,(x,y,2.9*scale),'tree_trunk',sections=12)
    for i,(z0,r,h0) in enumerate([(1.7,2.15,2.4),(2.8,1.95,2.35),(3.9,1.65,2.25),(5.0,1.30,2.05),(5.95,.85,1.65)]):
        m=trimesh.creation.cone(radius=r*scale,height=h0*scale,sections=24)
        m.apply_translation((x,y,(z0+h0/2)*scale))
        b.add(m,('tree_leaf3','tree_leaf2')[(i+variant)%2])

def add_willow(x,y,scale=1.0,variant=0):
    """Broad drooping willow silhouette used around the older garden."""
    h=4.2*scale;b.cyl(.25*scale,h,(x,y,h/2),'tree_trunk',sections=14)
    for i,a in enumerate(np.linspace(0,2*math.pi,9,endpoint=False)):
        rr=(1.4+0.22*(i%3))*scale
        cx=x+math.cos(a)*rr;cy=y+math.sin(a)*rr;cz=(4.3+0.28*(i%2))*scale
        key=('tree_leaf','tree_leaf2','tree_leaf3')[(i+variant)%3]
        b.sphere(1.25*scale,(cx,cy,cz),key,subdivisions=2,scale=(1.0,.88,1.35))
        # drooping geometry strands under the canopy edge
        for j in range(2):
            aa=a+(j-.5)*.18;ex=cx+math.cos(aa)*.45*scale;ey=cy+math.sin(aa)*.45*scale
            b.cylinder_between((cx,cy,cz-.25*scale),(ex,ey,cz-2.1*scale),.035*scale,'tree_leaf3',sections=6)

def add_streetlamp(x,y,rotz=0,scale=1.0):
    """Source-like slender road lamp with bent arm and separate luminaire."""
    ztop=5.7*scale;b.cyl(.075*scale,ztop,(x,y,ztop/2),'metal',sections=10)
    ar=math.radians(rotz);tip=(x+math.cos(ar)*1.15*scale,y+math.sin(ar)*1.15*scale,ztop+.25*scale)
    b.cylinder_between((x,y,ztop-.05*scale),tip,.055*scale,'metal',sections=8)
    b.box((.72*scale,.24*scale,.16*scale),(tip[0],tip[1],tip[2]-.08*scale),'stone',rotz=rotz)

def add_shrub(x,y,s=.55):
    # multi-lobed clipped shrub with softened geometry instead of one low-poly ellipsoid.
    b.sphere(s,(x,y,.50*s+0.25),'tree_leaf2',subdivisions=2,scale=(1.16,1.02,.66))
    b.sphere(.62*s,(x+.42*s,y-.18*s,.62*s+0.25),'tree_leaf3',subdivisions=2,scale=(1.0,.88,.64))

def add_ac_unit(cx,cy,z,rotz,normal=(0,1),scale=1.0):
    """Small wall-mounted condenser represented as geometry, including front grille and brackets."""
    nx,ny=normal
    b.box((1.05*scale,.48*scale,.70*scale),(cx,cy,z),'ac_body',rotz=rotz)
    # front grille is a dark inset plate plus pale ribs; no decal/texture.
    fx=cx+nx*.255*scale; fy=cy+ny*.255*scale
    b.box((.68*scale,.035*scale,.46*scale),(fx,fy,z+.01*scale),'ac_grill',rotz=rotz)
    th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)])
    for du in [-.25,-.125,0,.125,.25]:
        q=np.array([fx,fy])+ux*(du*scale);b.box((.025*scale,.055*scale,.39*scale),(q[0],q[1],z+.01*scale),'ac_body',rotz=rotz)
    # two steel support brackets below the box.
    for du in [-.34,.34]:
        q=np.array([cx,cy])+ux*(du*scale)
        b.box((.06*scale,.55*scale,.07*scale),(q[0],q[1],z-.43*scale),'metal',rotz=rotz)

def add_brick_strip(center,L,z0,z1,rotz=0,side_offset=0.0,rows=12,cols=8):
    """Latest-still red stair/core treatment: broad painted masonry panels with thin floor joints.
    Earlier versions used hundreds of protruding toy-like bricks; the latest still shows smooth red wall zones."""
    cx,cy=center;th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    panels=max(4,min(6,round((z1-z0)/3.1)))
    ph=(z1-z0)/panels
    for r in range(panels):
        q=np.array([cx,cy])+uy*side_offset
        b.box((L*.94,.10,ph*.88),(q[0],q[1],z0+(r+.5)*ph),'brick2',rotz=rotz)
        # very shallow pale horizontal reveal between floor-height panels
        if r<panels-1: b.box((L*.96,.115,.045),(q[0],q[1],z0+(r+1)*ph),'offwhite',rotz=rotz)

def roof_clutter(center,L,W,z,rotz=0,seed=1,count=7):
    """Geometry-only roof wear/service detail: raised repair plates, vents and low equipment."""
    rng=np.random.default_rng(seed);cx,cy=center;th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    for i in range(count):
        ss=rng.uniform(-L*.38,L*.38);tt=rng.uniform(-W*.28,W*.28);p=np.array([cx,cy])+ux*ss+uy*tt
        ll=rng.uniform(2.0,6.5);ww=rng.uniform(.8,2.2);b.box((ll,ww,.05),(p[0],p[1],z+.05),'roof_patch' if i%2==0 else 'roof_fade',rotz=rotz)
    for i in range(max(2,count//3)):
        ss=rng.uniform(-L*.34,L*.34);tt=rng.uniform(-W*.24,W*.24);p=np.array([cx,cy])+ux*ss+uy*tt
        b.cyl(.22,.65,(p[0],p[1],z+.35),'metal',sections=10)

def add_car(x,y,rotz=0,key='car_white',scale=1.0):
    # low body + tapered cabin + four wheels; all actual geometry.
    b.box((4.25*scale,1.82*scale,.62*scale),(x,y,.55*scale),key,rotz=rotz)
    # cabin wedge in local coordinates
    L=2.35*scale;W=1.58*scale;zb=.80*scale;zt=1.48*scale;topL=1.45*scale
    v=np.array([[-L/2,-W/2,zb],[L/2,-W/2,zb],[L/2,W/2,zb],[-L/2,W/2,zb],[-topL/2,-W*.46,zt],[topL/2,-W*.46,zt],[topL/2,W*.46,zt],[-topL/2,W*.46,zt]],float)
    f=np.array([[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7],[4,5,6],[4,6,7]])
    m=trimesh.Trimesh(v,f,process=False);b.add(m,key,translation_matrix((x,y,0))@rotation_matrix(math.radians(rotz),[0,0,1]))
    # dark windows as thin panels on both long sides
    th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    for side in [-1,1]:
        p=np.array([x,y])+uy*side*(W/2+.01);b.box((1.45*scale,.06,0.44*scale),(p[0],p[1],1.13*scale),'window_dark',rotz=rotz)
    # wheels
    for ss in [-1.35,1.35]:
        for side in [-1,1]:
            c=np.array([x,y])+ux*(ss*scale)+uy*(side*.93*scale)
            # short cylinder along local width direction
            uy3=np.array([uy[0],uy[1],0.0]);a=np.array([c[0],c[1],.42*scale])-uy3*.11*scale;d=np.array([c[0],c[1],.42*scale])+uy3*.11*scale
            b.cylinder_between(a,d,.31*scale,'dark',sections=12)

# ---------------- Terrain and hardscape ----------------
N=34;xs=np.linspace(-360,360,N);ys=np.linspace(-300,430,N);verts=[]
for y in ys:
    for x in xs:
        z=-.65+.0018*y+.10*math.sin(x/62)*math.cos(y/74);verts.append((x,y,z))
faces=[]
for j in range(N-1):
    for i in range(N-1):a=j*N+i;faces.extend([(a,a+1,a+N+1),(a,a+N+1,a+N)])
b.add(trimesh.Trimesh(np.asarray(verts),np.asarray(faces),process=False),'ground')
# campus roads and edge walks based on aerial references
for poly in [
 Polygon([(-175,-105),(170,-105),(170,-94),(-175,-94)]),
 Polygon([(138,-175),(150,-175),(150,176),(138,176)]),
 Polygon([(-175,113),(160,113),(160,126),(-175,126)]),
 Polygon([(-166,-170),(-154,-170),(-154,168),(-166,168)]),
 Polygon([(-145,68),(-120,82),(-86,88),(-50,85),(-35,78),(-38,68),(-90,72),(-128,60)])
]: b.extrude(poly,.10,-.08,'road')
# Explicit asphalt repair plates and utility covers; separate geometry, not procedural or image texture.
for x,y,L,W,r in [(-120,-100,18,2.2,0),(58,-100,11,1.6,0),(144,-30,2.0,18,0),(-160,38,2.4,14,0),(22,118,16,2.0,0)]:
    b.box((L,W,.018),(x,y,.035),'road2',rotz=r)
for x,y in [(-80,-100),(96,-100),(144,72),(-160,-40)]: b.cyl(.48,.025,(x,y,.045),'metal',sections=20)
# Source-visible raised road edges and drainage: shallow curb strips, regularly spaced storm grates,
# and a few repaired seams are modeled as solids rather than painted lines/texture decals.
for x,y,L,W,r in [
 (-2.5,-105.0,345,.22,0),(-2.5,-94.0,345,.22,0),
 (138.0,.5,.22,351,0),(150.0,.5,.22,351,0),
 (-7.5,113.0,335,.22,0),(-7.5,126.0,335,.22,0),
 (-166.0,-1.0,.22,338,0),(-154.0,-1.0,.22,338,0)
]: b.box((L,W,.18),(x,y,.05),'curb',rotz=r)
# Narrow dark drainage grates recessed along the south/east road margins.
for xx in np.arange(-142,151,18):
    b.box((1.15,.34,.035),(xx,-103.9,.055),'dark')
    for dx in np.linspace(-.42,.42,5): b.box((.045,.30,.018),(xx+dx,-103.9,.078),'metal')
for yy in np.arange(-150,161,18):
    b.box((.34,1.15,.035),(148.9,yy,.055),'dark')
    for dy in np.linspace(-.42,.42,5): b.box((.30,.045,.018),(148.9,yy+dy,.078),'metal')
# Irregular longitudinal repair seams visible as slightly raised asphalt patches, still geometry-only.
for pts in [[(-132,-98.8),(-104,-99.1),(-78,-98.6),(-48,-99.0)],[(84,-101.0),(104,-100.6),(126,-101.1)],[(142,-74),(143,-48),(142.5,-22),(143,4)]]:
    b.extrude(LineString(pts).buffer(.16,cap_style=1,join_style=1),.012,.052,'road2')

# Source-matched paved apron around the ceremonial circle. Near-vertical aerial frames show the circle
# embedded in a much broader pale hardscape, not isolated in grass.  Keep the crescent west side open.
plaza_apron=Polygon([(-39,-38),(34,-38),(48,-27),(51,27),(38,43),(-26,46),(-39,31)])
b.extrude(plaza_apron,.055,.055,'plaza_light')
# South/east approach paving and narrow red pedestrian margins.
b.extrude(Polygon([(-22,-54),(70,-54),(70,-39),(-22,-39)]),.045,.060,'path_light')
b.extrude(Polygon([(31,28),(59,28),(59,78),(42,78),(42,47),(31,47)]),.045,.060,'path_light')
b.extrude(Polygon([(-39,-39),(45,-39),(45,-36),(-39,-36)]),.020,.112,'plaza_red')
# Paving joints as actual thin geometry.
for xx in np.arange(-32,45,7): b.box((.035,72,.012),(xx,1,.126),'plaza_joint')
for yy in np.arange(-32,42,7): b.box((82,.035,.012),(3,yy,.126),'plaza_joint')
# Small irregular wet patches from the latest rainy plaza still. Geometry-only, no projected image.
for poly in [
 Polygon([(-18,-13),(-9,-15),(-3,-12),(-7,-9),(-16,-10)]),
 Polygon([(16,-24),(24,-23),(29,-19),(20,-18),(13,-20)]),
 Polygon([(29,10),(36,8),(39,13),(33,16),(27,14)]),
 Polygon([(-5,31),(5,30),(9,34),(1,36),(-7,35)])
]: b.extrude(poly,.008,.145,'plaza_dark')

# ---------------- Central ceremonial plaza ----------------
# Footage: broad pale outer circle, dark triangular annulus, pale inner annulus, red-grey center and white stepped monument.
ring(0,7.0,.05,'plaza_red',.10); ring(7.0,15.5,.05,'plaza_light',.10); ring(15.5,20.5,.05,'plaza_dark',.10); ring(20.5,28.5,.05,'plaza',.10)
# Hand-authored paving blocks: many separate stone pieces with small material differences; no UVs/images.
for k in range(48):
    a0=k*7.5; a1=(k+1)*7.5
    key=('plaza','stone_warm','plaza_light')[k%3]
    b.extrude(sector_polygon(20.65,28.35,a0+.18,a1-.18,8),.012,.158,key)
for k in range(32):
    a0=k*11.25; a1=(k+1)*11.25
    key=('plaza_light','stone_warm','plaza')[k%3]
    b.extrude(sector_polygon(7.15,15.35,a0+.22,a1-.22,7),.010,.158,key)
# eight broad radial sectors in the central disc, matching segment 10 close footage.
for k in range(8):
    if k%2==0:
        p=sector_polygon(.15,6.75,k*45+2,(k+1)*45-2,24)
        b.extrude(p,.035,.165,'plaza_teal')
for k in range(24):
    a0=2*math.pi*k/24;a1=2*math.pi*(k+1)/24;am=(a0+a1)/2;rin,rout=15.6,20.3
    p=Polygon([(rin*math.cos(a0),rin*math.sin(a0)),(rout*math.cos(am),rout*math.sin(am)),(rin*math.cos(a1),rin*math.sin(a1))])
    b.extrude(p,.055,.16,'plaza_red' if k%2==0 else 'plaza')
# paving-joint geometry: radial and concentric seams visible in the aerial footage (no texture maps).
for a in np.linspace(0,360,48,endpoint=False):
    ar=math.radians(a);r=24.5;x,y=r*math.cos(ar),r*math.sin(ar)
    b.box((8.0,.045,.018),(x,y,.178),'plaza_joint',rotz=a)
for rr in [21.5,23.7,25.8,27.8]: ring(rr-.035,rr+.035,.175,'plaza_joint',.018,128)
for rr in [9.0,12.0,14.7]: ring(rr-.025,rr+.025,.172,'plaza_joint',.016,128)

# central stepped white flag monument. Segment_10 close frames show a compact SQUARE stone platform,
# with square perimeter rails and stairs; V164's circular ring pedestal was a real geometry error.
for side,z,h in [(7.25,.19,.22),(6.45,.41,.22),(5.65,.63,.22)]:
    b.box((side,side,h),(0,0,z+h/2),'stone')
b.box((4.85,4.85,.34),(0,0,1.03),'stone')
# four three-step stair flights centered on each side
for ang in [0,90,180,270]:
    th=math.radians(ang); u=np.array([math.cos(th),math.sin(th)])
    for j in range(3):
        dist=2.62+j*.46; c=u*dist; z=.16+j*.14
        b.box((.62,2.52,.14),(c[0],c[1],z+.07),'stone',rotz=ang)
# square balustrade: solid posts and two rails, leaving a central opening at each stair.
for ang in [0,90,180,270]:
    th=math.radians(ang);u=np.array([math.cos(th),math.sin(th)]);v=np.array([-math.sin(th),math.cos(th)])
    edge=u*2.48
    # posts on both half-runs; stair opening is |t|<.75 m
    for t in [-2.15,-1.55,-.95,.95,1.55,2.15]:
        q=edge+v*t
        b.box((.22,.22,.95),(q[0],q[1],1.48),'stone',rotz=ang)
        b.sphere(.15,(q[0],q[1],2.00),'stone',subdivisions=1)
    for lo,hi in [(-2.22,-.82),(.82,2.22)]:
        mid=(lo+hi)/2; q=edge+v*mid
        # boxes are tangent-long and radially thin after rotation
        b.box((.18,hi-lo,.13),(q[0],q[1],1.78),'stone',rotz=ang)
        b.box((.16,hi-lo,.10),(q[0],q[1],1.37),'stone',rotz=ang)
# four slightly taller corner posts visible in the close pass
for x in [-2.48,2.48]:
    for y in [-2.48,2.48]:
        b.box((.28,.28,1.12),(x,y,1.53),'stone'); b.sphere(.18,(x,y,2.10),'stone',subdivisions=1)

# central plinth, polished flag pole, top cap and actual red cloth geometry
b.cyl(.58,.72,(0,0,1.45),'stone',sections=20)
b.cyl(.075,19.6,(0,0,11.45),'flagpole',sections=24)
b.sphere(.16,(0,0,21.55),'gold',subdivisions=2)
# Waving red flag: geometry only, double-sided triangles, no texture/image pixels.
ny,nz=9,5
v=[];f=[]
for iz in range(nz):
    z=19.95-iz*(2.25/(nz-1))
    for iy in range(ny):
        y=.10+iy*(3.45/(ny-1))
        x=.10*math.sin(iy*.95+iz*.45)+.045*(iy/(ny-1))**1.5
        v.append((x,y,z))
for iz in range(nz-1):
    for iy in range(ny-1):
        a=iz*ny+iy;c=a+1;d=(iz+1)*ny+iy;e=d+1
        f.extend([(a,d,e),(a,e,c),(e,d,a),(c,e,a)])
b.add(trimesh.Trimesh(np.asarray(v,float),np.asarray(f,int),process=False),'flag_red')

# ---------------- West administration / flag-plaza building ----------------
# Full-sequence aerial review + latest stills: this is a shallow faceted crescent wrapping the west
# side of the single ceremonial circle.  Earlier V164 incorrectly flattened it into one straight slab.
def add_admin_building():
    """Faceted crescent administration building around the ceremonial plaza.

    Plan geometry follows the aerial passes (segments 01 / 02.5 / 10); facade materials and the
    entrance / glass-stair language follow the six newer stills.  Every visible feature is geometry.
    """
    h=18.6
    r_mid=42.0
    depth=14.0
    a0,a1=130.0,226.0
    nseg=18
    edges=np.linspace(a0,a1,nseg+1)
    mids=(edges[:-1]+edges[1:])*.5
    # Eighteen tangent solids approximate the smooth source crescent while remaining actual geometry.
    seg_data=[]
    for i,(aa,bb,thd) in enumerate(zip(edges[:-1],edges[1:],mids)):
        th=math.radians(thd); da=math.radians(bb-aa)
        chord=2*r_mid*math.sin(da/2)+.42
        c=np.array([r_mid*math.cos(th),r_mid*math.sin(th)])
        rot=thd+90.0
        # Slightly taller central three bays and end stair/core slabs reproduce the stepped roofline.
        hh=h + (1.25 if abs(thd-180)<18 else 0.0) + (1.6 if i in (0,nseg-1) else 0.0)
        b.box((chord,depth,hh),(c[0],c[1],hh/2+.05),'admin_wall',rotz=rot)
        b.box((chord-.35,depth-.55,.34),(c[0],c[1],hh+.20),'roof',rotz=rot)
        seg_data.append((i,thd,th,c,rot,chord,hh))

    r_in=r_mid-depth/2
    r_out=r_mid+depth/2
    floors=5
    zrows=[2.25+i*3.25 for i in range(floors)]

    # Inner/plaza facade: repeated paired windows with physical sills, floor bands and vertical panel joints.
    for i,thd,th,c,rot,chord,hh in seg_data:
        inward=np.array([-math.cos(th),-math.sin(th)])
        tangent=np.array([-math.sin(th), math.cos(th)])
        face=np.array([r_in*math.cos(th),r_in*math.sin(th)]) + inward*.12
        central=abs(thd-180)<8.5
        stair_zone=(145<thd<153) or (207<thd<215)
        # per-segment floor bands / panel joints
        for z in [3.80,6.95,10.10,13.25,16.40,19.55]:
            b.box((max(.4,chord-.45),.10,.085),(face[0],face[1],z),'admin_wall2',rotz=rot)
        for uu in np.linspace(-chord*.38,chord*.38,3):
            q=face+tangent*uu
            b.box((.08,.12,max(2.0,hh-1.4)),(q[0],q[1],(hh-1.4)/2+.45),'admin_wall2',rotz=rot)
        if not central and not stair_zone and i%3!=1:
            slots=max(1,int(chord/3.25))
            for z in zrows:
                for uu in np.linspace(-chord*.38,chord*.38,slots):
                    q=face+tangent*uu
                    b.box((2.35,.18,1.62),(q[0],q[1],z),'window_dark',rotz=rot)
                    qs=q+inward*.035
                    b.box((1.83,.22,.10),(qs[0],qs[1],z+1.00),'admin_trim',rotz=rot)
                    b.box((.075,.23,1.52),(qs[0]+tangent[0]*.02,qs[1]+tangent[1]*.02,z),'admin_pale',rotz=rot)
                    b.box((1.83,.23,.065),(qs[0],qs[1],z),'admin_pale',rotz=rot)

    # Terminal end facades are visible obliquely in comparison view 1; model their window grids explicitly.
    for end_index,sign in [(0,-1),(len(seg_data)-1,1)]:
        i,thd,th,c,rot,chord,hh=seg_data[end_index]
        tangent=np.array([-math.sin(th),math.cos(th)])
        radial=np.array([math.cos(th),math.sin(th)])
        ec=c+tangent*(sign*chord*.50)
        # thin cladding plate keeps the tangent box seam from reading as a blank primitive face
        b.box((.12,depth-.8,hh-1.0),(ec[0],ec[1],(hh-1.0)/2+.25),'admin_wall2',rotz=rot)
        for z in zrows:
            for vv0 in np.linspace(-depth*.31,depth*.31,4):
                q=ec+radial*vv0
                for fs in [-1,1]:
                    qf=q+tangent*(fs*.10)
                    b.box((.10,1.72,1.45),(qf[0],qf[1],z),'glass_silver',rotz=rot)
                    b.box((.12,1.94,.10),(qf[0]+tangent[0]*fs*.03,qf[1]+tangent[1]*fs*.03,z+1.00),'admin_trim',rotz=rot)

    # Two vertical glass stair towers, set on the curved inner facade at the source-visible positions.
    for thd in [151.0,209.0]:
        th=math.radians(thd); inward=np.array([-math.cos(th),-math.sin(th)]); tangent=np.array([-math.sin(th),math.cos(th)])
        c=np.array([r_in*math.cos(th),r_in*math.sin(th)]) + inward*.25
        rot=thd+90
        b.box((4.75,3.65,20.3),(c[0],c[1],10.2),'glass_blue',rotz=rot)
        for z in np.linspace(1.30,19.45,8): b.box((4.88,3.82,.10),(c[0],c[1],z),'admin_trim',rotz=rot)
        for uu in np.linspace(-2.05,2.05,5):
            q=c+tangent*uu;b.box((.11,.25,19.3),(q[0],q[1],9.80),'admin_trim',rotz=rot)

    # Central entrance is radial: the AERIAL footprint remains a crescent, but latest stills 1/2 show
    # the entrance elevation itself as a broad FLAT datum.  This 32 m planar central bay hides the
    # old faceted-segment seams instead of pretending the entrance facade bends continuously.
    th=math.radians(180.0); inward=np.array([1.0,0.0]); tangent=np.array([0.0,-1.0])
    face=np.array([-r_in,0.0])
    b.box((1.10,32.0,h+.45),(face[0]-.34,0,(h+.45)/2),'admin_wall')
    # four source-visible side window stacks around the atrium on the flat datum
    for sy in [-14.0,-10.5,10.5,14.0]:
        for z in [8.1,11.35,14.60,17.85]:
            b.box((.22,2.45,1.72),(face[0]+.30,sy,z),'glass_silver')
            b.box((.27,.10,1.70),(face[0]+.42,sy,z),'admin_pale')
    # broad lower glazed lobby and upper atrium
    b.box((.40,24.5,5.55),(face[0]+.28,0,2.90),'glass_light',rotz=90)
    b.box((.36,11.4,12.4),(face[0]+.18,0,11.2),'glass_silver',rotz=90)
    for yy in np.linspace(-5.3,5.3,6): b.box((.42,.14,12.4),(face[0]+.42,yy,11.3),'admin_trim')
    for zz in [6.0,8.5,11.0,13.5,16.0,18.5]: b.box((.42,11.4,.14),(face[0]+.42,0,zz),'admin_trim')
    for yy in [-4.5,-1.5,1.5,4.5]:
        b.box((.14,2.15,2.80),(face[0]+.55,yy,1.55),'glass_blue')
        b.box((.18,.10,3.0),(face[0]+.64,yy+1.08,1.62),'admin_trim')
    # Square glass-block/lattice bays flanking the main lobby in the latest frontal still.
    for sy in [-11.5,11.5]:
        for iz in range(4):
            for iy in range(4):
                yy=sy+(iy-1.5)*1.05; zz=1.25+iz*.95
                b.box((.18,.78,.68),(face[0]+.60,yy,zz),'glass_light')
                b.box((.20,.10,.82),(face[0]+.72,yy+.43,zz),'admin_pale')
        b.box((.22,4.8,.14),(face[0]+.70,sy,5.0),'admin_pale')

    canopy_x=face[0]+2.25
    b.box((4.15,24.0,.24),(canopy_x,0,6.15),'glass_blue')
    for yy in [-8.4,-2.8,2.8,8.4]:
        b.cyl(.52,5.85,(canopy_x+.08,yy,3.12),'admin_column',sections=32)
        b.cyl(.59,.22,(canopy_x+.08,yy,.29),'admin_pale',sections=32)
        b.cyl(.59,.22,(canopy_x+.08,yy,6.00),'admin_pale',sections=32)
    for k in range(5): b.box((1.20+k*.62,21.7-k*.28,.13),(face[0]+1.05+k*.56,0,.12+k*.13),'stone_warm')

    # Central triangular glass gable.  Its orientation is unchanged in elevation but now sits on the correct curved plan.
    basez=h+.85; gx=face[0]+.26
    vv=np.array([[gx,-5.7,basez],[gx,5.7,basez],[gx,0,24.3],
                 [gx-.32,-5.7,basez],[gx-.32,5.7,basez],[gx-.32,0,24.3]],float)
    ff=np.array([[0,1,2],[5,4,3],[0,3,4],[0,4,1],[1,4,5],[1,5,2],[2,5,3],[2,3,0]],int)
    b.add(trimesh.Trimesh(vv,ff,process=False),'glass_silver')
    for yy in np.linspace(-5.2,5.2,6):
        topz=24.3-(abs(yy)/5.7)*(24.3-basez)
        b.cylinder_between((gx+.10,yy,basez),(gx+.10,yy,topz),.072,'admin_trim',sections=6)
    b.cylinder_between((gx+.10,-5.7,basez),(gx+.10,0,24.3),.085,'admin_trim',sections=6)
    b.cylinder_between((gx+.10,0,24.3),(gx+.10,5.7,basez),.085,'admin_trim',sections=6)

    # Outer/rear facade: pale repaint visible in newer material; windows follow each tangent segment.
    for i,thd,th,c,rot,chord,hh in seg_data:
        outward=np.array([math.cos(th),math.sin(th)]); tangent=np.array([-math.sin(th),math.cos(th)])
        face_o=np.array([r_out*math.cos(th),r_out*math.sin(th)])+outward*.10
        b.box((max(.4,chord-.35),.16,max(2.0,hh-1.1)),(face_o[0],face_o[1],(hh-1.1)/2+.25),'admin_light',rotz=rot)
        slots=max(1,int(chord/3.45))
        for z in zrows:
            for uu in np.linspace(-chord*.36,chord*.36,slots):
                q=face_o+tangent*uu
                b.box((2.05,.17,1.42),(q[0],q[1],z),'glass_silver',rotz=rot)

    # End slab fins / rooftop equipment and aerials: separate geometry, not silhouettes baked into textures.
    for thd in [136.4,223.6]:
        th=math.radians(thd); c=np.array([r_mid*math.cos(th),r_mid*math.sin(th)]); rot=thd+90
        is_end = thd < 140 or thd > 210
        zh=26.2 if is_end else 25.3
        fin_depth=4.6 if is_end else depth+.5
        b.box((2.8,fin_depth,zh),(c[0],c[1],zh/2+.05),'admin_wall2',rotz=rot)
    for thd,zh in [(149,26.0),(211,26.0)]:
        th=math.radians(thd); c=np.array([r_mid*math.cos(th),r_mid*math.sin(th)])
        b.box((5.4,5.6,2.1),(c[0],c[1],24.8),'admin_wall2',rotz=thd+90)
        b.cyl(.085,3.2,(c[0],c[1],27.0),'metal',sections=10)
add_admin_building()

# ---------------- Bespoke linear buildings ----------------
def add_linear(center,L,W,floors,rotz=0,red_trim=True,entry=True,roof_houses=True,side_bays=True):
    cx,cy=center;h=floors*3.15+1.0;th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    # stepped massing: long central bar plus slightly taller end stair towers
    b.box((L,W,h),(cx,cy,h/2+.05),'white',rotz=rotz)
    for end in [-1,1]:
        p=np.array([cx,cy])+ux*end*(L/2-3.0);b.box((6.2,W+1.0,h+1.4),(p[0],p[1],(h+1.4)/2+.05),'offwhite',rotz=rotz)
        if red_trim:b.box((6.5,W+1.4,1.0),(p[0],p[1],h+.9),'red',rotz=rotz)
    b.box((L-8,W-2,.30),(cx,cy,h+.25),'roof',rotz=rotz)
    # long side façades: windows inset between projected piers, red floor lines
    n=max(10,int(L/2.55))
    for side in [-1,1]:
        for f in range(floors):
            z=2.15+f*3.15
            for i in range(n):
                s=-L/2+3.4+(L-6.8)*i/(n-1);p=np.array([cx,cy])+ux*s+uy*side*(W/2+.12)
                b.box((1.62,.20,1.42),(p[0],p[1],z),'window_dark',rotz=rotz)
                # physical white aluminum frames: three vertical panes and a mid rail, not a single black square.
                for du in [-.54,0,.54]:
                    q=p+ux*du
                    b.box((.045,.23,1.38),(q[0],q[1],z),'offwhite',rotz=rotz)
                b.box((1.58,.23,.050),(p[0],p[1],z),'offwhite',rotz=rotz)
                b.box((1.68,.23,.055),(p[0],p[1],z+.73),'offwhite',rotz=rotz)
                b.box((1.68,.23,.055),(p[0],p[1],z-.73),'offwhite',rotz=rotz)
                # Separate lower infill panels keep the facade from reading as one flat color plane.
                pk=('offwhite','wall_warm','wall_cool')[(i+f+(0 if side<0 else 1))%3]
                b.box((1.68,.10,.30),(p[0],p[1],z-.98),pk,rotz=rotz)
            if red_trim:
                p=np.array([cx,cy])+uy*side*(W/2+.15);b.box((L-7,.16,.20),(p[0],p[1],z+1.13),'red',rotz=rotz)
        if side_bays:
            for bi,s0 in enumerate(np.linspace(-L/2+7,L/2-7,6)):
                p=np.array([cx,cy])+ux*s0+uy*side*(W/2+.28)
                if red_trim:
                    b.box((.68,.42,h-1.15),(p[0],p[1],(h-1.15)/2+.32),'brick2' if bi%2 else 'red2',rotz=rotz)
                    # thin pale edge strips keep each red stair/pier mass source-readable.
                    for du in [-.39,.39]:
                        q=p+ux*du;b.box((.055,.46,h-1.25),(q[0],q[1],(h-1.25)/2+.34),'offwhite',rotz=rotz)
                else:
                    b.box((.36,.52,h-1.2),(p[0],p[1],(h-1.2)/2+.3),'offwhite',rotz=rotz)
        # Exterior condenser units are repeatedly visible in the corridor/teaching-building footage.
        # Place them sparsely below selected windows so the facade is not a flat repeated grid.
        nrm=uy*side
        for f in range(1,floors):
            for i in range(1,n-1,4):
                ss=-L/2+3.4+(L-6.8)*i/(n-1);q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.47)
                add_ac_unit(q[0],q[1],1.35+f*3.15,rotz,normal=(nrm[0],nrm[1]),scale=.86)
    # source-visible red masonry stair/end-core relief; individual courses instead of a flat red patch.
    if red_trim:
        for end in [-1,1]:
            ep=np.array([cx,cy])+ux*end*(L/2-3.05)
            for side in [-1,1]:
                # narrow brick strip on the outer face of each end tower
                add_brick_strip((ep[0],ep[1]),4.6,.65,min(h-.8,12.8),rotz,side_offset=side*(W/2+.54),rows=max(24,floors*8),cols=12)
    # end windows and staircase vertical glass slit
    for end in [-1,1]:
        for f in range(floors):
            z=2.15+f*3.15
            for s in [-W*.22,W*.22]:
                p=np.array([cx,cy])+ux*end*(L/2+.12)+uy*s;b.box((1.45,.20,1.42),(p[0],p[1],z),'window_dark',rotz=rotz+90)
        p=np.array([cx,cy])+ux*end*(L/2+.2);b.box((2.8,.18,h-2.2),(p[0],p[1],h/2),'glass',rotz=rotz+90)
    if entry:
        p=np.array([cx,cy])+uy*(W/2+3.2);b.box((13,6.0,.42),(p[0],p[1],5.2),'white',rotz=rotz)
        for s in [-5,-1.7,1.7,5]:q=p+ux*s+uy*1.65;b.box((.58,.58,5.0),(q[0],q[1],2.55),'white',rotz=rotz)
        b.box((10.6,.18,2.8),(p[0],p[1],2.7),'glass',rotz=rotz)
    if roof_houses:
        for frac in [-.26,.29]:
            p=np.array([cx,cy])+ux*frac*L;b.box((5.0,4.8,2.4),(p[0],p[1],h+1.35),'offwhite',rotz=rotz);b.box((3.0,.18,1.3),(p[0],p[1]+.05,h+1.4),'glass',rotz=rotz)
    roof_clutter((cx,cy),L-10,W-4,h+.48,rotz,seed=int(abs(cx*7+cy*3))+11,count=max(4,int(L/15)))
    return h

# Observatory / science building on the east side, rebuilt from source 5/6.
def add_observatory(center=(0,-90),L=142,W=21.5,floors=4,rotz=0):
    """Science/observatory wing from comparison views 3/5/6.

    The central vehicle gateway is a genuine open void: the two wings and upper bridge are separate solids.
    """
    cx,cy=center;h=16.2
    th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    gap=28.0
    # Latest stills 5/6: the gateway is offset toward the right half; the dome-side LEFT wing is longer.
    # Keep the overall registered footprint unchanged, but split the bar at the source-visible opening.
    gate_s=6.0
    gcenter=np.array([cx,cy])+ux*gate_s
    left_a,left_b=-L/2, gate_s-gap/2
    right_a,right_b=gate_s+gap/2, L/2
    for aa,bb in [(left_a,left_b),(right_a,right_b)]:
        ww=bb-aa; mid=(aa+bb)/2; pc=np.array([cx,cy])+ux*mid
        b.box((ww,W,h),(pc[0],pc[1],h/2+.05),'white',rotz=rotz)
        b.box((ww-.8,W-1.0,.30),(pc[0],pc[1],h+.18),'offwhite',rotz=rotz)
    # upper bridge over gateway, leaving the lower drive-through physically open
    bridge_bottom=6.55
    bridge_h=h-bridge_bottom
    b.box((gap,W,bridge_h),(gcenter[0],gcenter[1],bridge_bottom+bridge_h/2),'white',rotz=rotz)
    b.box((gap-.5,W-1,.30),(gcenter[0],gcenter[1],h+.18),'offwhite',rotz=rotz)

    # Long red floor bands and real window solids on both long facades.
    for side in [-1,1]:
        face=np.array([cx,cy])+uy*side*(W/2+.14)
        for z in [3.75,6.90,10.05,13.20]:
            # split band at central opening on the front side for more faithful gateway read
            if side==-1 and z<6.7:
                for sg in [-1,1]:
                    q=face+ux*(gate_s + sg*(gap/2+(L-gap)/4))
                    b.box(((L-gap)/2-.5,.18,.26),(q[0],q[1],z),'red',rotz=rotz)
            else:b.box((L-2,.18,.26),(face[0],face[1],z),'red',rotz=rotz)
        for fl in range(4):
            z=2.20+fl*3.15
            bay_count = 11 if side==1 else 10
            for ss in np.linspace(-L/2+6,L/2-6,bay_count):
                if side==-1 and abs(ss-gate_s)<15.5 and z<6.7: continue
                if side==-1 and abs(ss-gate_s)<9 and z>6.5: continue
                q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.15)
                ww = 5.25 if side==1 else 4.85
                wh = 2.15 if side==1 else 2.05
                b.box((ww,.20,wh),(q[0],q[1],z),'glass_silver',rotz=rotz)
                # four-pane aluminum frame: latest still 5 has broad grouped windows, not tiny dark holes.
                for du in np.linspace(-ww/2+.65,ww/2-.65,4):
                    r=q+ux*du; b.box((.075,.25,wh-.08),(r[0],r[1],z),'offwhite',rotz=rotz)
                b.box((ww-.07,.25,.075),(q[0],q[1],z),'offwhite',rotz=rotz)

    # Segment08 courtyard side: several full-height glazed stacks are visibly larger than the front punched windows.
    rear=np.array([cx,cy])+uy*(W/2+.23)
    for ss in [-49,-43,-37,37,43,49]:
        for fl in range(4):
            z=2.20+fl*3.15; q=rear+ux*ss
            b.box((4.3,.25,2.18),(q[0],q[1],z),'glass_silver',rotz=rotz)
            b.box((.09,.29,2.10),(q[0],q[1],z),'offwhite',rotz=rotz)

    # Three dark glass stair shafts: two flank the gateway and one is near the far right end.
    for ss in [-24.0,L/2-8.0]:
        q=np.array([cx,cy])+ux*ss
        b.box((5.6,W+1.55,h+1.2),(q[0],q[1],(h+1.2)/2),'offwhite',rotz=rotz)
        qf=q+uy*(-1)*(W/2+.90)
        b.box((2.85,.22,h-2.0),(qf[0],qf[1],h/2),'glass_blue',rotz=rotz)
        for zz in np.linspace(2.5,h-1.8,6): b.box((2.90,.30,.10),(qf[0],qf[1],zz),'admin_trim',rotz=rotz)

    # Central glazed greenhouse/gable above the real opening.
    side=-1
    front=gcenter+uy*side*(W/2+.25)
    b.box((12.6,.30,5.9),(front[0],front[1],11.55),'glass_light',rotz=rotz)
    for ss in np.linspace(-6.1,6.1,6):
        q=front+ux*ss;b.box((.14,.42,6.65),(q[0],q[1],11.65),'offwhite',rotz=rotz)
    for zz in [8.55,10.55,12.55,14.55]: b.box((12.6,.42,.14),(front[0],front[1],zz),'offwhite',rotz=rotz)
    left=front+ux*(-6.3);right=front+ux*6.3;peak=np.array([front[0],front[1],h+3.25])
    b.add(trimesh.Trimesh(np.array([[left[0],left[1],h+.15],[right[0],right[1],h+.15],peak],float),np.array([[0,1,2],[2,1,0]],int),process=False),'glass_roof')
    b.cylinder_between((left[0],left[1],h+.15),peak,.09,'green_metal',sections=6)
    b.cylinder_between(peak,(right[0],right[1],h+.15),.09,'green_metal',sections=6)
    for ss in np.linspace(-5.3,5.3,5):
        q=front+ux*ss; topz=h+.15+(1-abs(ss)/6.3)*(3.15)
        b.cylinder_between((q[0],q[1],h+.15),(q[0],q[1],topz),.06,'green_metal',sections=5)

    # Open gateway architecture: upper beam and four tall columns, actual empty space between them.
    gate=front+uy*side*2.55
    b.box((30.2,4.5,1.00),(gate[0],gate[1],6.95),'roof2',rotz=rotz)
    for ss in [-10.5,-3.5,3.5,10.5]:
        q=gate+ux*ss;b.box((1.38,1.38,6.45),(q[0],q[1],3.28),'offwhite',rotz=rotz)
        b.box((1.58,1.58,.35),(q[0],q[1],.28),'admin_trim',rotz=rotz)
    # dark fascia panel above the driveway and short red end caps
    b.box((27.0,.24,1.14),(gate[0]+uy[0]*2.12,gate[1]+uy[1]*2.12,6.58),'roof2',rotz=rotz)

    # Geodesic observatory dome at left roof wing, moderate scale (not the former oversized sphere).
    dp=np.array([cx,cy])+ux*(-44.5)+uy*(1.8)
    drum_r=5.05; dome_r=4.80
    b.cyl(drum_r,4.25,(dp[0],dp[1],h+2.25),'offwhite',sections=64)
    for a in np.linspace(0,360,10,endpoint=False):
        ar=math.radians(a);x=dp[0]+(drum_r+.07)*math.cos(ar);y=dp[1]+(drum_r+.07)*math.sin(ar)
        b.box((1.08,.18,1.42),(x,y,h+2.25),'window_dark',rotz=a)
    # The close drone pass shows a nearly spherical geodesic cap, with its lower quarter buried in the drum.
    sph=trimesh.creation.icosphere(subdivisions=3,radius=dome_r)
    sph.vertices[:,2]*=.92
    sph.apply_translation((dp[0],dp[1],h+3.60+dome_r*.66))
    b.add(sph,'dome')
    for e in sph.edges_unique:
        a=sph.vertices[e[0]];c=sph.vertices[e[1]]
        if a[2]>h+3.35 and c[2]>h+3.35:b.cylinder_between(a,c,.043,'dome_dark',sections=5)

    # Source 5/6: the dome-side wing is a broad multi-storey glass grid spanning roughly 30 m.
    # Build it as physical grouped glazing and mullions rather than three token blue strips.
    facade_y=np.array([cx,cy])+uy*(-1)*(W/2+.31)
    for ss in np.linspace(-60.0,-31.0,7):
        q0=facade_y+ux*ss
        # Latest still 5 has four separate rows of tall white-framed windows; the white slab bands remain visible.
        for fl in range(4):
            z=2.35+fl*3.18
            b.box((3.45,.24,2.18),(q0[0],q0[1],z),'glass_silver',rotz=rotz)
            for du in [-1.12,0,1.12]:
                r=q0+ux*du; b.box((.105,.31,2.10),(r[0],r[1],z),'offwhite',rotz=rotz)
            b.box((3.42,.31,.09),(q0[0],q0[1],z),'offwhite',rotz=rotz)
    # Physical AC condenser rows and drain/down-pipe accents visible on the white facade.
    for ss in np.linspace(-58,58,14):
        if abs(ss)<17: continue
        q=np.array([cx,cy])+ux*ss+uy*(-1)*(W/2+.48)
        b.box((1.18,.34,.72),(q[0],q[1],2.65),'ac_body',rotz=rotz)
        b.box((.74,.08,.44),(q[0],q[1]+(-1 if abs(uy[1])>.5 else 0)*.03,2.65),'ac_grill',rotz=rotz)

    # roof service rooms, vents and weathering plates
    for ss in [-18,18,48]:
        q=np.array([cx,cy])+ux*ss;b.box((7.5,5.3,2.3),(q[0],q[1],h+1.45),'offwhite',rotz=rotz)
    roof_clutter((cx,cy),L-15,W-5,h+.45,rotz,seed=513,count=13)
    return h,dp

# Aerial review places the dome-bearing long wing on the east side, running roughly north-south.
b.set_transform(rotation_matrix(math.radians(90),[0,0,1]))
h_east,dc=add_observatory(center=(-76,-92),L=138,W=21.5)
b.reset_transform()

# ---------------- East science forecourt / parking / main gate ----------------
# Comparison views 5/6 show a large paved forecourt, parked cars, clipped tree rows and a campus gate
# between the camera and the science building. Everything below is modeled geometry.
b.extrude(Polygon([(110,-134),(192,-134),(192,-37),(110,-37)]),.08,.02,'road2')
# central pedestrian/vehicle axis to the science gateway
b.extrude(Polygon([(103,-96),(198,-96),(198,-76),(103,-76)]),.06,.11,'plaza_light')
# parking bay joints
for yy in [-128,-121,-114,-58,-51,-44]: b.box((69,.055,.018),(149,yy,.13),'court_joint')
for xx in np.linspace(118,186,13):
    for yy in [-121,-51]: b.box((.055,13,.018),(xx,yy,.13),'court_joint')
# two dense car rows; varied colors and slight offsets prevent a toy-like exact grid
car_keys=['car_white','car_dark','car_white','car_red','car_white']
for row,yy in enumerate([-48.5]):
    for i,xx in enumerate(np.linspace(119,184,12)):
        if (i+row)%7==0: continue
        add_car(xx,yy+(0.45 if i%3==0 else 0),rotz=-90,key=car_keys[(i+2*row)%len(car_keys)],scale=.82)
# Latest comparison still 6: a low, long brown hipped-roof building occupies the SOUTH side of
# the science forecourt; V181/V182 incorrectly filled this whole area with a mirrored parking row.
def add_science_forecourt_low_annex(cx=129.0,cy=-121.0,sx=16.0,sy=23.0,h=3.8):
    b.box((sx,sy,h),(cx,cy,h/2+.05),'wall_warm')
    # shallow hipped roof with a long north-south ridge, matching the still's low brown roof silhouette
    x0,x1=cx-sx/2-1.0,cx+sx/2+1.0; y0,y1=cy-sy/2-1.0,cy+sy/2+1.0
    rz=h+2.25; ez=h+.28; ridge_half=sy/2-5.0
    verts=np.array([[x0,y0,ez],[x1,y0,ez],[x1,y1,ez],[x0,y1,ez],
                    [cx,cy-ridge_half,rz],[cx,cy+ridge_half,rz]],float)
    faces=np.array([[0,1,4],[0,4,3],[3,4,5],[3,5,2],[2,5,1],[1,5,4]],int)
    b.add(trimesh.Trimesh(verts,faces,process=False),'roof_patch')
    # east-facing entry glazing / sheltered opening visible through the foreground trees
    for yy in np.linspace(cy-sy/2+5,cy+sy/2-5,4):
        b.box((.20,3.4,2.15),(x1+.12,yy,2.0),'glass_silver',rotz=90)
    b.box((2.2,sy-4,.35),(x1+1.1,cy,3.75),'offwhite')
    # small west service projection
    b.box((5.0,8.0,3.2),(x0-2.3,cy+5.5,1.65),'wall_warm')
    b.box((5.4,8.4,.24),(x0-2.3,cy+5.5,3.35),'roof2')
add_science_forecourt_low_annex()

# clipped tree rows flanking the central approach
for yy in [-104.5,-67.5]:
    for i,xx in enumerate(np.linspace(116,181,10)):
        add_tree(xx,yy,scale=.78+(i%3)*.08,variant=i)
        add_shrub(xx+2.0,yy*.93,.70)
# low hedges seen along the left approach of view 5
for xx in np.linspace(114,170,15): b.box((2.9,1.25,1.05),(xx,-109.5,.60),'tree_leaf2')

# Gate nearest comparison view 6. Broad horizontal lintel with two chunky side pylons and center plaque.
gate_x=160.0
# open gate is built from separate pylons and lintel solids, leaving the drive-through physically empty.
b.box((4.8,9.0,7.2),(gate_x,-106.2,3.65),'admin_pale')
b.box((4.8,9.0,7.2),(gate_x,-65.8,3.65),'admin_pale')
b.box((4.8,31.0,1.25),(gate_x,-86,6.55),'admin_pale')
b.box((.22,8.0,2.7),(gate_x-2.52,-106.2,3.1),'glass_blue')
b.box((.22,8.0,2.7),(gate_x-2.52,-65.8,3.1),'glass_blue')
# center signboard and modeled red/gold vertical strokes (not text/image texture)
b.box((.22,7.2,4.2),(gate_x-2.58,-86,3.25),'admin_pale')
for z0 in [4.5,3.6,2.7,1.8]:
    b.box((.12,2.2,.16),(gate_x-2.73,-86,z0),'gold')
    b.box((.12,.16,.72),(gate_x-2.73,-86.72,z0),'gold')
# physical sliding-bar fence sections either side of gate
for yy0 in [-128,-120,-52,-44]:
    for zz in [.7,1.55,2.4]: b.box((.09,7.5,.07),(gate_x-1.8,yy0,zz),'metal')
    for yy in np.linspace(yy0-3.3,yy0+3.3,6): b.box((.09,.07,2.4),(gate_x-1.8,yy,1.3),'metal')

# Large mature trees framing supplied comparison view 2.
for x0,y0,sc,var in [(34,-13,2.25,0),(36,13,2.35,1),(27,-20,1.8,2),(28,21,1.95,0),(41,-23,1.55,1),(41,24,1.65,2)]:
    add_tree(x0,y0,sc,var)
for x0,y0,sc,var in [(44.0,-12.5,3.0,1),(44.2,13.0,3.1,2)]: add_tree(x0,y0,sc,var)
# lower hedges along the approach from view 2
for y0 in np.linspace(-26,26,10): add_shrub(25.5,y0,.85)

# ---------------- Distant urban edge and mountain ridges ----------------
# These are geometry-only horizon masses seen in the aerial comparison views; they also keep the enlarged
# ground from ending in a hard rectangular edge in long-distance views.
def add_mountain_ridge(points, width=72, base=-.55, key='mountain'):
    # Densified 7-row terrain ribbon. It is still pure geometry, but avoids the old giant flat triangles.
    dense=[]
    for i in range(len(points)-1):
        a=np.asarray(points[i],float);c=np.asarray(points[i+1],float)
        for k in range(8):
            t=k/8.0;q=a*(1-t)+c*t
            # gentle non-repeating height break-up derived mathematically, not sampled from imagery
            q[2]+=2.6*math.sin((i*8+k)*1.31)+1.3*math.sin((i*8+k)*.47)
            dense.append(q)
    dense.append(np.asarray(points[-1],float))
    rows=np.linspace(-1,1,7);verts=[];faces=[]
    for j,q in enumerate(dense):
        x,y,z=q;l=max(1.0,math.hypot(x,y));nx,ny=x/l,y/l
        for u in rows:
            fall=(1-abs(u)**1.55)
            zz=base+(z-base)*fall + 1.2*math.sin(j*.73+u*2.1)*fall
            verts.append((x+nx*u*width*.52,y+ny*u*width*.52,zz))
    nr=len(rows)
    for j in range(len(dense)-1):
        for r in range(nr-1):
            a=j*nr+r;c=(j+1)*nr+r;faces.extend([(a,c,c+1),(a,c+1,a+1)])
    b.add(trimesh.Trimesh(np.asarray(verts,float),np.asarray(faces,int),process=False),key)
# west / north / northeast ridgelines, irregular enough to avoid a synthetic smooth wall
add_mountain_ridge([(-340,-230,18),(-355,-130,31),(-345,-30,46),(-350,70,39),(-340,170,52),(-325,280,38)],85,-.55,'mountain')
add_mountain_ridge([(-290,390,20),(-180,405,31),(-65,414,38),(50,405,34),(165,398,49),(285,385,42)],92,-.55,'mountain2')
add_mountain_ridge([(335,320,34),(350,220,46),(352,120,39),(350,20,28),(345,-90,41),(335,-205,30)],80,-.55,'mountain')
for a in np.linspace(-145,145,24):
    ar=math.radians(a); rr=305+12*math.sin(a*.17); add_tree(rr*math.cos(ar),rr*math.sin(ar)+80,.72+(int(a)%3)*.10,int(a)%3)
# distant city blocks beyond science / in aerial horizon; intentionally simple because they remain hundreds of metres away.
for ix,x0 in enumerate([-250,-210,-165,-120,-75,15,60,110,160,215,260]):
    for jy,y0 in enumerate([610,645]):
        hh=14+((ix*7+jy*11)%17)
        b.box((26,18,hh),(x0,y0,hh/2),'urban' if (ix+jy)%2 else 'urban_dark')
        for z0 in np.arange(4,hh-1,3.2):
            for xx in np.linspace(x0-9,x0+9,4): b.box((1.7,.14,1.2),(xx,y0-9.1,z0),'glass_silver')

# Courtyard classroom / dormitory blocks seen around plaza and gardens.
# Source-guided central layout revision: the two northern teaching bars sit northwest/north of the
# ceremonial circle; the southern teaching bars run north-south.  The old V110/V111 placements
# incorrectly put three long bars through the west garden and are intentionally removed.
# Registered overhead mosaic (segment 02.5, frames 18-35 s) fixes the central five-building group:
# two nearer bars around y~+67 m and three rear bars around y~+91 m.  V114 had them stretched to y=119/202.
# Registered segment_02.5 correction: the two lower north blocks kink inward toward the circle,
# while the three upper bars remain close to N-S. Centers are shifted east/south to the mosaic evidence.
def add_gray_teaching(center,L,W,floors=5,rotz=90,core_end=1):
    """Latest-still gray teaching block: plain gray field, narrow white-framed windows and one orange-red stair core."""
    cx,cy=center;h=floors*3.18+1.0;th=math.radians(rotz)
    ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    b.box((L,W,h),(cx,cy,h/2+.05),'north_gray')
    b.box((L-2.0,W-1.0,.28),(cx,cy,h+.20),'north_roof',rotz=rotz)
    # one source-visible orange/red vertical end core; opposite end remains gray.
    ep=np.array([cx,cy])+ux*core_end*(L/2-3.0)
    b.box((5.0,W+1.0,h+.7),(ep[0],ep[1],(h+.7)/2+.05),'north_core',rotz=rotz)
    # narrow paired windows on both long facades, no obsolete red horizontal waist bands.
    n=max(8,int(round(L/6.0)))
    for side in [-1,1]:
        nrm=uy*side
        for fl in range(floors):
            z=2.15+fl*3.18
            for i,ss in enumerate(np.linspace(-L/2+4,L/2-4,n)):
                if abs(ss-core_end*(L/2-3))<3.4: continue
                q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.13)
                b.box((3.25,.19,1.52),(q[0],q[1],z),'glass_silver',rotz=rotz)
                for du in [-1.05,-.35,.35,1.05]:
                    qq=q+ux*du;b.box((.040,.235,1.42),(qq[0],qq[1],z),'offwhite',rotz=rotz)
                b.box((3.18,.235,.050),(q[0],q[1],z),'offwhite',rotz=rotz)
                if fl in (1,3) and i%5==1:
                    add_ac_unit(q[0]+nrm[0]*.32,q[1]+nrm[1]*.32,z-.92,rotz,normal=(nrm[0],nrm[1]),scale=.78)
        # subtle vertical gray pilasters between window groups visible in the renovated facade.
        for ss in np.linspace(-L/2+7,L/2-7,5):
            q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.22)
            b.box((.22,.30,h-1.2),(q[0],q[1],(h-1.2)/2+.35),'north_gray2',rotz=rotz)
    # end face windows on the gray end, plus slit glazing within the stair core.
    gray_end=-core_end
    for fl in range(floors):
        z=2.15+fl*3.18
        q=np.array([cx,cy])+ux*gray_end*(L/2+.12)
        for sw in [-W*.22,W*.22]:
            p0=q+uy*sw;b.box((1.35,.18,1.40),(p0[0],p0[1],z),'glass_silver',rotz=rotz+90)
    cface=np.array([cx,cy])+ux*core_end*(L/2+.18)
    b.box((2.0,.20,h-2.0),(cface[0],cface[1],h/2),'glass_blue',rotz=rotz+90)
    # rooftop stair machine rooms / vents from the latest oblique image.
    for frac in [-.22,.25]:
        q=np.array([cx,cy])+ux*frac*L;b.box((5.4,4.5,2.1),(q[0],q[1],h+1.25),'north_roof',rotz=rotz)
    roof_clutter((cx,cy),L-8,W-4,h+.42,rotz,seed=int(abs(cx*11+cy*5)),count=max(4,int(L/13)))
    return h

# V181 Expert-3 rebuild: the two plaza-near north blocks are single bent footprints traced from
# segment_02.5 t31.0 and homography-registered to the panorama.  They are NOT unions of overlapping boxes.
def add_gray_polygon_teaching(points, floors=5, core_anchor=None, core_key='north_core', seed=1700):
    poly=Polygon(points)
    h=floors*3.18+1.0
    b.extrude(poly,h,.05,'north_gray')
    # inset roof slab follows the measured footprint instead of creating a separate rectangular cap.
    roofpoly=poly.buffer(-.45, join_style=2)
    if roofpoly.is_empty: roofpoly=poly
    b.extrude(roofpoly,.28,h+.05,'north_roof')
    ring=list(poly.exterior.coords)[:-1]
    # per-edge facade glazing: only long exposed edges receive rows; panels are geometry, not textures.
    for ei,(a,c) in enumerate(zip(ring, ring[1:]+ring[:1])):
        a=np.asarray(a,float); c=np.asarray(c,float); v=c-a; L=float(np.linalg.norm(v))
        if L<5.5: continue
        u=v/L; rot=math.degrees(math.atan2(v[1],v[0]))
        nslots=max(2,int(L/5.2)); margin=min(3.0,L*.18)
        for fl in range(floors):
            z=2.15+fl*3.18
            for ss in np.linspace(margin,L-margin,nslots):
                q=a+u*ss
                ww=min(3.35,max(2.0,(L-2*margin)/max(nslots,1)*.70))
                b.box((ww,.22,1.48),(q[0],q[1],z),'glass_silver',rotz=rot)
                for du in [-ww*.28,0,ww*.28]:
                    r=q+u*du; b.box((.045,.27,1.42),(r[0],r[1],z),'offwhite',rotz=rot)
                b.box((ww,.27,.055),(q[0],q[1],z),'offwhite',rotz=rot)
        # renovated gray vertical pilasters, deliberately sparse.
        for ss in np.linspace(margin,L-margin,max(2,int(L/12))):
            q=a+u*ss;b.box((.24,.34,h-1.2),(q[0],q[1],(h-1.2)/2+.35),'north_gray2',rotz=rot)
    if core_anchor is not None:
        cx,cy,rot=core_anchor
        b.box((5.6,15.8,h+.75),(cx,cy,(h+.75)/2+.05),core_key,rotz=rot)
        th=math.radians(rot); normal=np.array([-math.sin(th),math.cos(th)])
        q=np.array([cx,cy])+normal*8.5
        b.box((2.0,.24,h-2.0),(q[0],q[1],h/2),'glass_silver',rotz=rot)
    minx,miny,maxx,maxy=poly.bounds
    # small roof machine rooms placed safely inside the footprint centroid line.
    cc=np.array(poly.representative_point().coords[0])
    b.box((5.0,4.4,2.0),(cc[0],cc[1],h+1.20),'north_roof')
    roof_clutter(tuple(cc),max(6,maxx-minx-5),max(5,maxy-miny-5),h+.42,0,seed=seed,count=4)
    return h

# Legacy union-of-boxes helper retained only for reproducibility; V170 no longer calls it.
def add_gray_L_teaching(main_center, main_L, wing_center, wing_L, wing_rot, core_end=1):
    add_gray_teaching(main_center,main_L,16.5,5,90,core_end)
    cx,cy=wing_center; h=5*3.18+1.0; th=math.radians(wing_rot)
    ux=np.array([math.cos(th),math.sin(th)]); uy=np.array([-math.sin(th),math.cos(th)])
    b.box((wing_L,16.5,h),(cx,cy,h/2+.05),'north_gray',rotz=wing_rot)
    b.box((wing_L-1.0,15.4,.28),(cx,cy,h+.20),'north_roof',rotz=wing_rot)
    for side in [-1,1]:
        for fl in range(5):
            z=2.15+fl*3.18
            for ss in np.linspace(-wing_L/2+4,wing_L/2-4,max(5,int(wing_L/4.2))):
                q=np.array([cx,cy])+ux*ss+uy*side*(16.5/2+.13)
                b.box((2.15,.19,1.46),(q[0],q[1],z),'glass_silver',rotz=wing_rot)
                b.box((.06,.235,1.42),(q[0],q[1],z),'offwhite',rotz=wing_rot)
                b.box((2.08,.235,.05),(q[0],q[1],z),'offwhite',rotz=wing_rot)
    # Both terminal faces are visible in t28.7/t31.0 and the latest oblique still; do not leave primitive blank end walls.
    for endsgn in [-1,1]:
        endc=np.array([cx,cy])+ux*endsgn*(wing_L/2+.13)
        for fl in range(5):
            z=2.15+fl*3.18
            for vv in [-4.8,-2.4,0,2.4,4.8]:
                q=endc+uy*vv
                b.box((.20,1.55,1.44),(q[0],q[1],z),'glass_silver',rotz=wing_rot+90)
                b.box((.24,.06,1.40),(q[0],q[1],z),'offwhite',rotz=wing_rot+90)
        for zz in [3.7,6.9,10.1,13.3,16.2]: b.box((.24,15.3,.13),(endc[0],endc[1],zz),'north_gray2',rotz=wing_rot+90)
    roof_clutter((cx,cy),wing_L-6,11.5,h+.42,wing_rot,seed=int(abs(cx*17+cy*7))+809,count=4)

# Three rear/northern bars visible at the top of t31.0/t33.2.
add_gray_teaching((-96,104),54,15.8,5,90,1)
add_gray_teaching((-65,104),55,15.8,5,90,1)
add_gray_teaching((-34,104),53,15.5,5,90,1)
# V170: two independent bent footprints traced from t31.0 -> panorama homography.
# Their south returns remain separated by ~13 m; the V169 overlap/near-touch error is removed.
north_bent_west=[(-107.7,82.0),(-94.4,82.2),(-92.5,60.5),(-84.5,57.8),(-87.3,46.7),(-93.6,46.5),(-104.9,54.8),(-105.8,59.8)]
north_bent_east=[(-65.4,83.8),(-51.7,84.2),(-50.9,63.2),(-43.8,60.5),(-52.1,49.6),(-57.5,49.7),(-64.2,57.3),(-64.4,63.0)]
add_gray_polygon_teaching(north_bent_west,5,core_anchor=(-88.6,51.8,-14),core_key='north_core',seed=1701)
add_gray_polygon_teaching(north_bent_east,5,core_anchor=(-48.5,55.0,-34),core_key='north_core',seed=1702)
# V164 gray teaching roofs are generated inside add_gray_teaching; stale V139 cap proxies removed.
def add_grouped_teaching(center,L,W,floors=4,rotz=90,red_core_end=-1,entry_side=-1,roof_pergola=True):
    """Source-specific white/red teaching block with broad grouped bays rather than generic tiny-window repetition."""
    cx,cy=center; h=floors*3.25+1.0; th=math.radians(rotz)
    ux=np.array([math.cos(th),math.sin(th)]); uy=np.array([-math.sin(th),math.cos(th)])
    b.box((L,W,h),(cx,cy,h/2+.05),'white',rotz=rotz)
    b.box((L-1.1,W-1.0,.30),(cx,cy,h+.19),'stadium_gray',rotz=rotz)
    # latest stills show one strong full-height red stair/core; the opposite terminal mass remains pale.
    for end in [-1,1]:
        ep=np.array([cx,cy])+ux*end*(L/2-3.4)
        if end==red_core_end:
            b.box((8.6,W+1.0,h+.65),(ep[0],ep[1],(h+.65)/2+.05),'brick2',rotz=rotz)
        else:
            b.box((5.2,W+.35,h+.25),(ep[0],ep[1],(h+.25)/2+.05),'offwhite',rotz=rotz)
        facep=np.array([cx,cy])+ux*end*(L/2+.13)
        b.box((2.2,.20,h-2.1),(facep[0],facep[1],h/2),'glass_silver',rotz=rotz+90)
    # four/five storey broad grouped window bays. Each group is a real recess with mullions and red vertical piers.
    groups=max(7,int(round(L/16.0)))
    usable=L-15.0; group_pitch=usable/groups
    for side in [-1,1]:
        face=np.array([cx,cy])+uy*side*(W/2+.13)
        for fl in range(floors):
            z=2.25+fl*3.25
            for gi in range(groups):
                ss=-usable/2+(gi+.5)*group_pitch
                q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.14)
                ww=min(8.3,max(6.7,group_pitch-5.0))
                b.box((ww,.20,1.55),(q[0],q[1],z),'glass_silver',rotz=rotz)
                # 4 vertical panes plus mid rail
                for du in np.linspace(-ww/2+.65,ww/2-.65,5):
                    r=q+ux*du;b.box((.07,.24,1.50),(r[0],r[1],z),'offwhite',rotz=rotz)
                b.box((ww,.24,.06),(q[0],q[1],z),'offwhite',rotz=rotz)
            # thin red floor line from latest white/red facade
            b.box((L-8,.18,.20),(face[0],face[1],z+1.17),'red2',rotz=rotz)
        for gi in range(groups+1):
            ss=-usable/2+gi*group_pitch
            q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.22)
            b.box((1.15,.38,h-1.15),(q[0],q[1],(h-1.15)/2+.32),'brick2',rotz=rotz)
    # roof rooms and open pergola near circle-facing/north end.
    for frac in [-.22,.20]:
        q=np.array([cx,cy])+ux*frac*L;b.box((5.8,5.0,2.1),(q[0],q[1],h+1.28),'offwhite',rotz=rotz)
    if roof_pergola:
        pp=np.array([cx,cy])+ux*(L/2-9.0)
        b.box((9.5,7.4,.26),(pp[0],pp[1],h+3.0),'offwhite',rotz=rotz)
        for a in [-3.8,3.8]:
            for c in [-2.7,2.7]:
                q=pp+ux*a+uy*c;b.box((.42,.42,2.85),(q[0],q[1],h+1.55),'offwhite',rotz=rotz)
    roof_clutter((cx,cy),L-12,W-5,h+.45,rotz,seed=int(abs(cx*13+cy*17))+221,count=max(5,int(L/15)))
    return h

# V181 Expert-3 rebuild of the latest-still banner teaching block.  This is intentionally asymmetric:
# one full-height red stair/core at the south end, a low left-side entrance annex near the banner, and seven broad facade bays.
def add_banner_teaching(center=(-23.5,-96),L=115,W=15.5,floors=5,rotz=90):
    cx,cy=center; h=floors*3.25+1.0; th=math.radians(rotz)
    ux=np.array([math.cos(th),math.sin(th)]); uy=np.array([-math.sin(th),math.cos(th)])
    b.box((L,W,h),(cx,cy,h/2+.05),'white',rotz=rotz)
    b.box((L-1.2,W-1.0,.30),(cx,cy,h+.19),'stadium_gray',rotz=rotz)
    # source 4: strong red core on the south/right image end only. North end remains mostly white.
    ep=np.array([cx,cy])-ux*(L/2-4.3)
    b.box((9.0,W+1.0,h+.70),(ep[0],ep[1],(h+.70)/2+.05),'brick2',rotz=rotz)
    endface=np.array([cx,cy])-ux*(L/2+.13)
    for fl in range(floors):
        z=2.25+fl*3.25
        for sw in [-2.0,2.0]:
            q=endface+uy*sw;b.box((1.55,.22,1.46),(q[0],q[1],z),'glass_silver',rotz=rotz+90)
    # west-facing principal facade seen in latest still 4: seven wide modules, with white spandrels and narrow red piers.
    side=1; usable=L-23.0; groups=6; pitch=usable/groups
    for fl in range(floors):
        z=2.25+fl*3.25
        for gi in range(groups):
            ss=-usable/2+(gi+.5)*pitch+2.0
            q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.15)
            ww=max(7.2,pitch-6.0)
            # ground floor is a little taller/recessed; upper rows use broad multi-pane bands.
            hh=1.75 if fl==0 else 1.52
            b.box((ww,.22,hh),(q[0],q[1],z),'glass_silver',rotz=rotz)
            for du in np.linspace(-ww/2+.7,ww/2-.7,4):
                r=q+ux*du;b.box((.065,.27,hh-.06),(r[0],r[1],z),'offwhite',rotz=rotz)
        # red horizontal waist only at source-visible slab line, not dense cage grid.
        face=np.array([cx,cy])+uy*side*(W/2+.24)
        if fl>0: b.box((L-13,.18,.17),(face[0],face[1],z+1.16),'red2',rotz=rotz)
    for gi in range(groups+1):
        ss=-usable/2+gi*pitch+2.0
        q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.26)
        b.box((.92,.38,h-1.1),(q[0],q[1],(h-1.1)/2+.33),'brick2',rotz=rotz)
    # rear/east facade remains simpler but is fully modeled.
    side=-1
    for fl in range(floors):
        z=2.25+fl*3.25
        for ss in np.linspace(-L/2+9,L/2-12,10):
            q=np.array([cx,cy])+ux*ss+uy*side*(W/2+.14)
            b.box((5.4,.20,1.48),(q[0],q[1],z),'glass_silver',rotz=rotz)
    # low white entrance/service annex immediately beside the banner, source 4.
    b.box((3.0,12.0,3.65),(-32.55,-64.8,1.88),'offwhite')
    b.box((3.15,12.3,.42),(-32.65,-64.8,3.78),'red2')
    for yy in [-69.0,-66.2,-63.4,-60.6]: b.box((.24,1.65,2.15),(-34.10,yy,1.95),'glass_silver',rotz=90)
    # small rooftop service rooms and slim canopy, visible but not exaggerated.
    for frac in [-.20,.18]:
        q=np.array([cx,cy])+ux*frac*L;b.box((5.5,4.8,2.0),(q[0],q[1],h+1.23),'offwhite',rotz=rotz)
    roof_clutter((cx,cy),L-14,W-5,h+.45,rotz,seed=1704,count=7)
    return h

# V182 Expert-3 correction from segment_02.5 t20-23 s and t55-58 s plus latest still 3:
# there are THREE parallel south teaching bars before the separate science/observatory wing.
# V181's 'two-bar' interpretation omitted the entire east/third bar and was the recurring obvious layout error.
add_banner_teaching((-23.5,-96),115,15.5,5,90)
add_grouped_teaching((12.0,-96),116,15.5,5,90,red_core_end=-1,entry_side=1,roof_pergola=False)
add_grouped_teaching((47.5,-96),116,15.5,5,90,red_core_end=-1,entry_side=1,roof_pergola=False)

# V184 Expert-3: circle-facing/north terminal headhouses from segment_02.5 t57.5-58.5 s.
# All three bars terminate in a tall white headwall framed by red side piers, with a dark flat roof and
# an open lower portal.  Earlier versions used a small pale cap / floating roof pergola, which is visibly wrong.
def add_circle_end_headhouse(cx, y_end=-38.4, h=17.25, variant=0):
    # broad white terminal wall integrated with the long bar
    b.box((15.7,5.4,h+.20),(cx,y_end-2.45,(h+.20)/2+.05),'offwhite')
    # red outer shoulders/pier frames seen clearly in the near-nadir source
    for sx in [-1,1]:
        b.box((2.65,6.0,h+.65),(cx+sx*6.25,y_end-2.15,(h+.65)/2+.05),'brick2')
    # dark flat roof with pale parapet lip
    b.box((15.9,6.2,.34),(cx,y_end-2.15,h+.32),'roof')
    for sx in [-1,1]: b.box((2.7,6.25,.35),(cx+sx*6.25,y_end-2.15,h+.40),'brick2')
    # open two-bay ground portal toward the ceremonial circle
    for sx in [-5.2,0,5.2]: b.box((.42,1.0,4.1),(cx+sx,y_end+.70,2.10),'offwhite')
    b.box((15.2,1.05,.52),(cx,y_end+.70,4.15),'offwhite')
    # source-visible central slim vertical dark/green-grey service strip and small upper windows
    b.box((.42,.24,h-5.4),(cx,y_end+.55,10.0),'window_dark')
    for z in [7.0,10.2,13.4]:
        for sx in [-3.4,3.4]: b.box((2.3,.22,1.45),(cx+sx,y_end+.63,z),'glass_silver')
    # small AC/utility solids on the outer face, varied slightly per bar
    for j,z in enumerate([9.0,12.4]):
        side=-1 if (j+variant)%2==0 else 1
        b.box((1.05,.30,.65),(cx+side*3.2,y_end+.75,z),'ac_body')

for vv,cx in enumerate([-23.5,12.0,47.5]): add_circle_end_headhouse(cx,variant=vv)
# Three long bars remain independent; there is no semicircular connector between them.

# V164: duplicate east-long block removed after direct source registration.


# V183 Expert-3 correction from continuous segment_02.5 t20-23 s / t57.5-58.5 s and segment_06 t7.5-10.5 s:
# V182's single semicircular connector between bars 1/2 was another topology error.  The near-nadir
# frames show THREE independent long bars whose aligned south ends each carry a separate D-shaped /
# rounded five-storey end wing.  The dark roof lobes nearly touch in plan, which caused the earlier
# false "one connector" reading, but the paved gaps remain open between the three buildings.
def add_south_rounded_endcap(cx, y_join=-153.45, radius=15.0, h=17.0, variant=0):
    """Independent rounded south end wing for one teaching bar; pure geometry, no image/UV texture."""
    # D-plan: diameter lies on the straight bar's south termination; the semicircle bulges south.
    ang=np.linspace(180.0,360.0,73)
    arc=[(cx+radius*math.cos(math.radians(a)), y_join+radius*math.sin(math.radians(a))) for a in ang]
    poly=Polygon(arc+[(cx+radius,y_join),(cx-radius,y_join)])
    b.extrude(poly,h,.05,'white')
    # weather-dark flat roof matching the aerial source, inset slightly so the white parapet remains legible.
    rr=radius-.62
    arc2=[(cx+rr*math.cos(math.radians(a)), y_join+rr*math.sin(math.radians(a))) for a in ang]
    roofpoly=Polygon(arc2+[(cx+rr,y_join-.20),(cx-rr,y_join-.20)])
    b.extrude(roofpoly,.30,h+.06,'roof')

    # Convex curved facade: broad white-framed glazing, five rows, red horizontal waist bands.
    # Segment_06/10 ground views show a continuous curve rather than radial box ribs, so only facade
    # elements are tangent boxes; the building body itself is one continuous extrusion.
    bay_angles=np.linspace(198,342,10)
    for fl in range(5):
        z=2.10+fl*3.08
        for a in bay_angles:
            th=math.radians(a); radial=np.array([math.cos(th),math.sin(th)])
            tangent=np.array([-math.sin(th),math.cos(th)])
            q=np.array([cx,y_join])+radial*(radius+.13)
            rot=a+90
            # grouped 3-pane window, not a dense raster-like facade
            b.box((2.18,.20,1.50),(q[0],q[1],z),'glass_silver',rotz=rot)
            for du in [-.72,0,.72]:
                r=q+tangent*du; b.box((.055,.25,1.42),(r[0],r[1],z),'offwhite',rotz=rot)
            b.box((2.14,.25,.060),(q[0],q[1],z),'offwhite',rotz=rot)
        # continuous visual band approximated by 18 tangent geometry strips around the arc
        for a in np.linspace(190,350,18):
            th=math.radians(a); radial=np.array([math.cos(th),math.sin(th)])
            q=np.array([cx,y_join])+radial*(radius+.10)
            rot=a+90
            chord=radius*math.radians(10.0)*1.03
            b.box((chord,.12,.18),(q[0],q[1],z+1.18),'red2',rotz=rot)

    # Vertical facade piers and two dark service/stair strips seen on the rounded end wings.
    for a in np.linspace(194,346,7):
        th=math.radians(a); radial=np.array([math.cos(th),math.sin(th)])
        q=np.array([cx,y_join])+radial*(radius+.22)
        b.box((.24,.30,h-1.1),(q[0],q[1],(h-1.1)/2+.35),'offwhite',rotz=a+90)
    for a in ([214,326] if variant%2==0 else [220,320]):
        th=math.radians(a); radial=np.array([math.cos(th),math.sin(th)])
        q=np.array([cx,y_join])+radial*(radius+.28)
        b.box((1.10,.22,h-2.0),(q[0],q[1],h/2),'window_dark',rotz=a+90)

    # Straight north attachment / side returns close the plan into the original 15.5 m bar without
    # inventing bridges between neighbouring buildings.
    b.box((15.5,5.0,h),(cx,y_join+2.45,h/2+.05),'white')
    b.box((14.8,4.3,.28),(cx,y_join+2.45,h+.18),'roof')
    # source-visible low side rooms at the outer corners differ slightly between bars.
    side=(-1 if variant==0 else 1 if variant==1 else -1)
    b.box((6.4,6.8,7.1),(cx+side*(radius-3.4),y_join-1.2,3.6),'white')
    b.box((6.0,6.4,.28),(cx+side*(radius-3.4),y_join-1.2,7.25),'roof2')
    for fl in range(2):
        z=2.15+fl*3.05
        b.box((2.8,.20,1.45),(cx+side*(radius+.11),y_join-1.2,z),'glass_silver',rotz=90)

    # Small rooftop stair/service box near the junction, visible in the t57.5/t58 aerials.
    b.box((6.2,6.4,2.45),(cx + (3.0 if variant!=1 else -3.0), y_join-1.0, h+1.42),'offwhite')

# Three separate source-confirmed rounded end wings; narrow paved gaps remain between them.
add_south_rounded_endcap(-23.5,-153.45,15.3,17.0,0)
add_south_rounded_endcap( 12.0,-153.45,15.0,17.0,1)
add_south_rounded_endcap( 47.5,-153.45,14.7,17.0,2)

# Source 4/latest still: geometry-only vertical encouragement banner on the west-facing facade.
banner_x,banner_y=-31.40,-74.0
b.box((.22,6.45,14.7),(banner_x,banner_y,9.80),'red')
for ch,z0 in zip('撸起袖子加油干',[15.55,13.80,12.05,10.30,8.55,6.80,5.05]):
    add_bitmap_text_yz(ch,banner_x-.18,banner_y,z0,3.55,1.78,'gold',depth=.16,font_px=96,bold=True)
b.sphere(.58,(banner_x-.16,banner_y-.95,16.45),'glass_blue',subdivisions=2,scale=(.22,1.0,1.0))
b.sphere(.32,(banner_x-.19,banner_y-.95,16.84),'admin_pale',subdivisions=2,scale=(.20,1.0,1.0))
# narrow upper portal immediately above the low annex; the old floating full-height cage is removed.
b.box((2.15,14.0,3.2),(-32.35,-64.4,7.0),'brick2')
b.box((2.30,10.4,2.25),(-33.50,-64.4,6.55),'glass_silver')

# comparison view 4 foreground is a dense planted garden rather than bare ground
for ix,x0 in enumerate(np.linspace(-44,-4,8)):
    for iy,y0 in enumerate(np.linspace(-108,-58,7)):
        if (ix+2*iy)%3==0: add_tree(x0,y0,.72+((ix+iy)%4)*.12,(ix+iy)%3)
        elif (ix+iy)%2==0: add_shrub(x0,y0,.52+((ix*iy)%3)*.09)

# Open corridor/balcony skins on several classroom blocks, matching ground-level footage of red-trimmed external galleries.
def open_corridor(center,L,W,floors,rotz=0,side=1):
    cx,cy=center;th=math.radians(rotz);ux=np.array([math.cos(th),math.sin(th)]);uy=np.array([-math.sin(th),math.cos(th)])
    for f in range(1,floors):
        z=f*3.15+.15;p=np.array([cx,cy])+uy*side*(W/2+1.1)
        b.box((L-7,2.0,.18),(p[0],p[1],z),'offwhite',rotz=rotz)
        # red rail / fascia and slim uprights
        p2=np.array([cx,cy])+uy*side*(W/2+2.0);b.box((L-7,.12,.28),(p2[0],p2[1],z+.72),'red',rotz=rotz)
        for ss in np.linspace(-L/2+5,L/2-5,max(6,int(L/5))):
            q=np.array([cx,cy])+ux*ss+uy*side*(W/2+1.95);b.box((.12,.12,1.15),(q[0],q[1],z+.55),'offwhite',rotz=rotz)
        # structural gallery columns and alternating door/window openings behind the rail.
        for j,ss in enumerate(np.linspace(-L/2+6,L/2-6,max(5,int(L/7)))):
            qc=np.array([cx,cy])+ux*ss+uy*side*(W/2+1.72);b.box((.30,.30,2.75),(qc[0],qc[1],z+1.48),'offwhite',rotz=rotz)
            qw=np.array([cx,cy])+ux*(ss+1.55)+uy*side*(W/2+.14);b.box((1.45,.18,2.12),(qw[0],qw[1],z+1.28),'window_dark' if j%2 else 'glass',rotz=rotz)
# South parallel blocks carry the same source-visible open gallery language.
open_corridor((-23.5,-96),115,15.5,5,90,-1)
open_corridor((12,-96),116,15.5,5,90,1)

# Red-gable ancillary building seen in rooftop/pass-through shots
b.box((35,14,8.3),(-84,-164,4.2),'white'); gable_roof(-84,-164,37,16,8.35,0,'red2',5.3)
for yside in [-171.1,-156.9]:
    for x in np.linspace(-98,-70,9): b.box((1.7,.24,1.7),(x,yside,4.6),'window_dark')
# translucent/metal rooftop canopies as real framing geometry
for cx,cy in [(-58,-160),(-34,-160)]:
    for xx in np.linspace(cx-7,cx+7,5):
        b.cylinder_between((xx,cy-4,10.0),(xx,cy+4,10.0),.08,'green_metal',sections=6)
    for yy in np.linspace(cy-4,cy+4,4):b.cylinder_between((cx-7,yy,10),(cx+7,yy,10),.08,'green_metal',sections=6)

# ---------------- Northeast assembly / auditorium complex ----------------
def add_hall_polygon(points,h=10.8,roof_key='stadium_gray',wall_key='offwhite',roof_rise=.18):
    poly=Polygon(points)
    b.extrude(poly,h,.05,wall_key)
    # Near-nadir frames t31/t33 show broad almost-flat weathered membrane roofs, not peaked fan roofs.
    if roof_key is not None:
        b.extrude(poly,.22,h+.05,roof_key)
        ring=list(poly.exterior.coords)[:-1]
        # physical parapet/ridge around the measured roof perimeter
        for a,c in zip(ring,ring[1:]+ring[:1]):
            a=np.asarray(a,float); c=np.asarray(c,float); v=c-a; L=float(np.linalg.norm(v))
            if L<.2: continue
            mid=(a+c)/2; ang=math.degrees(math.atan2(v[1],v[0]))
            b.box((L,.28,.30),(mid[0],mid[1],h+.32),'stadium_pale',rotz=ang)
        # roof service/seam lines as actual thin geometry (source t31/t33), never a texture.
        minx,miny,maxx,maxy=poly.bounds
        for yy in np.linspace(miny+3,maxy-3,5):
            seg=LineString([(minx,yy),(maxx,yy)]).intersection(poly.buffer(-.9))
            geoms=list(seg.geoms) if getattr(seg,'geom_type','')=='MultiLineString' else [seg]
            for g in geoms:
                if getattr(g,'length',0)<2: continue
                a=np.asarray(g.coords[0],float); c=np.asarray(g.coords[-1],float); v=c-a; L=float(np.linalg.norm(v)); mid=(a+c)/2
                b.box((L,.08,.06),(mid[0],mid[1],h+.29),'roof2',rotz=math.degrees(math.atan2(v[1],v[0])))
        for xx in np.linspace(minx+4,maxx-4,5):
            seg=LineString([(xx,miny),(xx,maxy)]).intersection(poly.buffer(-.9))
            geoms=list(seg.geoms) if getattr(seg,'geom_type','')=='MultiLineString' else [seg]
            for g in geoms:
                if getattr(g,'length',0)<2: continue
                a=np.asarray(g.coords[0],float); c=np.asarray(g.coords[-1],float); v=c-a; L=float(np.linalg.norm(v)); mid=(a+c)/2
                b.box((L,.07,.05),(mid[0],mid[1],h+.31),'roof_fade',rotz=math.degrees(math.atan2(v[1],v[0])))
    minx,miny,maxx,maxy=poly.bounds
    for i,(dx,dy) in enumerate([(-.18,-.10),(.20,.12)]):
        x=minx+(maxx-minx)*(.5+dx); y=miny+(maxy-miny)*(.5+dy)
        b.box((3.5,2.8,.85),(x,y,h+.66),'roof2')

def add_atrium_hall():
    # V185 Expert-3 rebuild from segment_02.5 t31-33 near-nadir frames.
    # The source is TWO large interlocking irregular roof plates around a dark concave courtyard,
    # not three parallel hall slabs.  Preserve the registered overall envelope but correct topology.
    hall_nw=[(-16,105),(31,105),(39,95),(33,82),(13,78),(-10,82),(-18,92)]
    hall_se=[(18,84),(54,88),(67,77),(61,50),(24,44),(8,55),(10,72)]
    add_hall_polygon(hall_nw,11.5,'stadium_gray','offwhite',.25)
    add_hall_polygon(hall_se,10.7,'stadium_gray','offwhite',.25)

    # Source-visible dark recessed court at the re-entrant join; kept physically open to the sky.
    court=Polygon([(5.0,77.0),(17.0,78.5),(25.0,70.0),(16.5,59.0),(5.0,61.0),(-0.5,69.0)])
    b.extrude(court,.06,.08,'road2')

    # One central glass atrium/pyramid spans the join.  A smaller glazed connector sits on the red-wing end.
    def _hall_glass_pyramid(ax,ay,z0,zp,hw,hh):
        verts=np.array([[ax-hw,ay-hh,z0],[ax+hw,ay-hh,z0],[ax+hw,ay+hh,z0],[ax-hw,ay+hh,z0],[ax,ay,zp]],float)
        faces=np.array([[0,1,4],[1,2,4],[2,3,4],[3,0,4]])
        b.add(trimesh.Trimesh(verts,faces,process=False),'glass_roof')
        for i,j in [(0,1),(1,2),(2,3),(3,0),(0,4),(1,4),(2,4),(3,4)]: b.cylinder_between(verts[i],verts[j],.07,'green_metal',sections=6)
    _hall_glass_pyramid(10.5,73.0,11.55,15.4,6.0,4.6)
    _hall_glass_pyramid(25.0,51.0,10.8,13.7,4.5,3.2)

    # Long red-roof auditorium wing lies on the SOUTH/EAST edge of the complex, as in the source,
    # rather than incorrectly running between the two main roof plates.
    b.box((50.0,12.0,9.0),(43.0,48.0,4.55),'offwhite',rotz=-3)
    gable_roof(43.0,48.0,52.0,13.5,9.05,-3,'red2',3.9)
    # Glazed end tower where the red wing meets the main hall.
    b.box((7.5,11.5,9.3),(18.4,49.3,4.7),'glass_light',rotz=-3)
    for zz in [2.4,5.0,7.6]:
        b.box((7.1,.16,.12),(18.4,43.5,zz),'green_metal',rotz=-3)
    for xx in np.linspace(21,63,9):
        for zz in [2.6,5.4,8.0]: b.box((2.7,.20,1.55),(xx,42.1,zz),'glass_silver',rotz=-3)

    # White wall bands / windows only on exposed perimeter edges; no generic facade template.
    for x in np.linspace(-8,27,7):
        for z in [2.6,5.5,8.4]: b.box((2.3,.20,1.45),(x,82.0,z),'glass_silver',rotz=-5)
    for y in np.linspace(56,78,5):
        for z in [2.6,5.5,8.4]: b.box((.20,2.2,1.45),(61.8,y,z),'glass_silver')
    for zz in [3.55,6.65,9.75]:
        b.box((38.0,.17,.17),(6.0,81.8,zz),'red2',rotz=-5)
        b.box((.17,26.0,.17),(62.0,65.0,zz),'red2')
add_atrium_hall()
# detached red-gable service annex visible north-east of the complex
b.box((15,9,6.8),(59,104,3.45),'white'); gable_roof(59,104,17,11,6.9,0,'red2',3.2)
for xx in np.linspace(54,64,4): b.box((1.3,.18,1.25),(xx,99.4,3.5),'glass_silver')

# ---------------- Gardens ----------------
west=Polygon([(-122,-22),(-104,18),(-75,27),(-54,7),(-56,-40),(-64,-88),(-84,-122),(-113,-134),(-126,-103),(-128,-58)]);b.extrude(west,.09,.02,'grass2')
# court/plaza-side planted strip
for poly in [Polygon([(-40,42),(38,42),(38,61),(-40,61)]),Polygon([(-100,76),(-34,76),(-34,103),(-100,103)])]:b.extrude(poly,.08,.02,'grass')
# V164: source-traced west-garden circulation from the registered near-nadir 02.5 mosaic + segment_09.
# The earlier four circular loops were a clear layout error: the real garden is an irregular branching network.
def _catmull_rom(points,samples=12):
    # Smooth, interpolating curve through all surveyed waypoints. End points are duplicated so paths
    # start/end exactly on their registered nodes instead of bowing away from them.
    P=[np.array(q,float) for q in points]
    if len(P)<3: return points
    ext=[P[0]]+P+[P[-1]]; out=[]
    for i in range(1,len(ext)-2):
        p0,p1,p2,p3=ext[i-1],ext[i],ext[i+1],ext[i+2]
        for t in np.linspace(0,1,samples,endpoint=False):
            t2=t*t;t3=t2*t
            q=.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t2+(-p0+3*p1-3*p2+p3)*t3)
            out.append(tuple(q))
    out.append(tuple(P[-1]));return out

def garden_path(pts,width=2.05):
    smooth=_catmull_rom(pts,14)
    b.extrude(LineString(smooth).buffer(width/2,cap_style=1,join_style=1,resolution=10),.09,.12,'path_light')
    return smooth

# Main descending spine and organic branches. Coordinates are in the same registered campus frame as
# the table-tennis slabs and the ceremonial circle; paths intentionally meet at shared nodes.
garden_paths=[
 [(-120,-34),(-113,-43),(-103,-50),(-94,-58),(-86,-67),(-80,-78),(-77,-91),(-74,-106),(-69,-119)],
 [(-110,-48),(-118,-58),(-121,-70),(-117,-81),(-108,-88),(-98,-84),(-91,-75),(-86,-67)],
 [(-117,-81),(-122,-92),(-119,-104),(-111,-112),(-101,-115),(-91,-111),(-81,-102),(-77,-91)],
 [(-103,-50),(-98,-61),(-99,-73),(-106,-84),(-108,-88)],
 [(-91,-75),(-82,-68),(-72,-62),(-64,-68),(-61,-79),(-65,-91),(-74,-99),(-81,-102)],
 [(-98,-84),(-91,-92),(-86,-103),(-91,-111)],
 [(-111,-112),(-116,-122),(-112,-130),(-101,-133),(-90,-128),(-81,-118),(-74,-106)],
 [(-101,-115),(-102,-126),(-96,-132)],
 [(-65,-91),(-59,-101),(-61,-111),(-69,-119)],
 [(-122,-92),(-114,-96),(-106,-95),(-98,-84)]
]
smooth_garden_paths=[]
for pts in garden_paths: smooth_garden_paths.append(garden_path(pts,2.0 if len(pts)<7 else 2.15))
# Only the two source-visible small junction pads are circular; they are nodes, not looped paths.
for x,y,r in [(-108,-88,1.55),(-74,-106,1.40)]: ring(0,r,.14,'path',.06,48,(x,y))
# Thin path-edge curb strips give the garden routes a readable real paved edge without using textures.
for pts in [smooth_garden_paths[0],smooth_garden_paths[1],smooth_garden_paths[2],smooth_garden_paths[4],smooth_garden_paths[6]]:
    edge=LineString(pts).buffer(1.24,cap_style=1,join_style=1,resolution=10).difference(LineString(pts).buffer(1.05,cap_style=1,join_style=1,resolution=10))
    if not edge.is_empty: b.extrude(edge,.055,.155,'curb')
# Dense mature planting rows around the west garden and plaza, matching the source canopy density.
for i,(x0,y0) in enumerate([
 (-121,-30),(-121,-45),(-120,-61),(-118,-78),(-116,-96),(-108,-115),
 (-103,-23),(-95,-29),(-87,-31),(-79,-28),(-70,-32),(-62,-38),
 (-111,-52),(-101,-61),(-91,-54),(-82,-66),(-72,-58),(-64,-72),
 (-110,-85),(-99,-91),(-87,-82),(-77,-94),(-65,-103),
 (-31,35),(-20,39),(-8,41),(5,42),(18,40),(30,37),
 (36,31),(42,23),(45,13),(46,2),(46,-10),(43,-23),(39,-33),
 (31,-39),(20,-43),(7,-45),(-7,-45),(-20,-42),(-30,-36)
]):
    if min(math.hypot(x0+101,y0+96),math.hypot(x0+101,y0-18))>7.2:
        add_tree(x0,y0,.78+(i%5)*.10,i%3)
    if i%2==0: add_shrub(x0+2.2,y0-1.6,.55+(i%3)*.08)
# Low clipped hedge ribbons along the plaza/garden transition.
for yy in np.linspace(-28,28,11): add_shrub(-39.5,yy,.52)
for xx in np.linspace(-24,34,12): add_shrub(xx,46.5,.48)

# central approach paving
for poly in [Polygon([(-9,41),(9,41),(9,104),(-9,104)]),Polygon([(-55,-8),(-41,-8),(-41,8),(-55,8)]),Polygon([(44,-7),(72,-7),(72,7),(44,7)])]:b.extrude(poly,.10,.10,'path_light')

# Paved/tree-lined pedestrian courts immediately around the observatory and north teaching blocks.
b.extrude(Polygon([(-44,-54),(70,-54),(70,-49),(-44,-49)]),.075,.055,'path')
b.extrude(Polygon([(36,26),(72,26),(72,78),(36,78)]),.075,.045,'path_light')
# planted islands in the east courtyard
for x0 in [42,59]:
    b.extrude(Polygon([(x0,52),(x0+8,52),(x0+8,102),(x0,102)]),.10,.10,'grass_dark')
# evenly spaced small courtyard trees matching the aerial rows
for yy in np.linspace(32,74,7):
    add_tree(38,yy,.72,int(yy)%3);add_tree(74,yy,.72,(int(yy)+1)%3)
for i,xx in enumerate(np.linspace(-38,60,12)): add_tree(xx,-53,.70,i%3)
# low benches along the plaza-to-observatory walk
for xx in np.linspace(-32,54,6):
    b.box((.45,2.2,.18),(xx,-48.5,.50),'offwhite');b.box((.16,.16,.55),(xx,-49.3,.27),'metal');b.box((.16,.16,.55),(xx,-47.7,.27),'metal')

# Chinese pavilion in west garden: curved/upturned double eaves, columns, brackets and railings.
def pagoda_roof(cx,cy,z,half,peak,upturn,key='red2',N=14,thick=.16):
    # square hipped roof with curved eaves; corners turn upward. Generate a thin closed shell from a regular grid.
    xs=np.linspace(-half,half,N);ys=np.linspace(-half,half,N);verts=[]
    def zz(x,y):
        q=max(abs(x),abs(y))/half
        base=peak*(1-q**1.15)
        corner=upturn*((abs(x*y)/(half*half))**3.2)
        return z+base+corner
    for layer in [0,-thick]:
        for y in ys:
            for x in xs:verts.append((cx+x,cy+y,zz(x,y)+layer))
    faces=[];off=N*N
    for j in range(N-1):
        for i in range(N-1):
            a=j*N+i;c=a+1;d=(j+1)*N+i;e=d+1
            faces.extend([(a,c,e),(a,e,d),(off+a,off+e,off+c),(off+a,off+d,off+e)])
    # close four perimeter sides
    for i in range(N-1):
        # bottom/top y edges
        for a,c in [(i,i+1),((N-1)*N+i,(N-1)*N+i+1)]:faces.extend([(a,off+a,off+c),(a,off+c,c)])
        # left/right x edges
        for a,c in [(i*N,(i+1)*N),(i*N+N-1,(i+1)*N+N-1)]:faces.extend([(a,c,off+c),(a,off+c,off+a)])
    b.add(trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=False),key)

def pavilion(cx=-101,cy=-96):
    # Two-storey garden pavilion from segments 05/08: open lower level, enclosed timber upper chamber, double upturned eaves.
    b.box((8.2,8.2,.48),(cx,cy,.29),'plaza_light')
    # lower four structural columns
    for dx in [-2.55,2.55]:
      for dy in [-2.55,2.55]:
        b.cyl(.23,3.78,(cx+dx,cy+dy,2.18),'red2',sections=18)
        for z0,span in [(3.36,1.15),(3.57,1.48)]:
            b.box((span,.25,.15),(cx+dx,cy+dy,z0),'gold');b.box((.25,span,.15),(cx+dx,cy+dy,z0),'gold')
    # lower sweeping roof
    pagoda_roof(cx,cy,3.68,4.82,1.72,.56,'tile_red_dark',18,.18)
    # enclosed upper chamber clearly visible in the close footage
    chamber_z0=4.78; chamber_h=2.05; chamber_half=2.05
    for dx in [-chamber_half,chamber_half]:
      for dy in [-chamber_half,chamber_half]: b.cyl(.19,chamber_h,(cx+dx,cy+dy,chamber_z0+chamber_h/2),'red2',sections=16)
    # dark timber sill/top beams and ornate-looking dense lattice windows on all four sides
    for dy in [-chamber_half,chamber_half]:
        b.box((4.35,.18,.20),(cx,cy+dy,chamber_z0+.12),'dark');b.box((4.35,.18,.20),(cx,cy+dy,chamber_z0+chamber_h-.12),'gold')
        for xx in np.linspace(-1.72,1.72,7): b.box((.10,.16,1.35),(cx+xx,cy+dy,chamber_z0+1.05),'dark')
        for zz in np.linspace(chamber_z0+.42,chamber_z0+1.70,4): b.box((3.75,.16,.08),(cx,cy+dy,zz),'dark')
    for dx in [-chamber_half,chamber_half]:
        b.box((.18,4.35,.20),(cx+dx,cy,chamber_z0+.12),'dark');b.box((.18,4.35,.20),(cx+dx,cy,chamber_z0+chamber_h-.12),'gold')
        for yy in np.linspace(-1.72,1.72,7): b.box((.16,.10,1.35),(cx+dx,cy+yy,chamber_z0+1.05),'dark')
        for zz in np.linspace(chamber_z0+.42,chamber_z0+1.70,4): b.box((.16,3.75,.08),(cx+dx,cy,zz),'dark')
    # Dense dougong / painted beam clusters under both eaves, visible in the close segment_05 pass.
    # These are layered solids: red main block, dark cantilever, green/gold cap - no ornament texture.
    for side in [-1,1]:
        for u in np.linspace(-3.35,3.35,7):
            # south/north lower eave brackets
            yb=cy+side*3.48
            b.box((.62,.34,.30),(cx+u,yb,3.47),'red2')
            b.box((.88,.22,.16),(cx+u,yb-side*.20,3.30),'dark')
            b.box((.42,.38,.14),(cx+u,yb+side*.18,3.62),'green_metal')
            b.box((.25,.42,.12),(cx+u,yb+side*.30,3.72),'gold')
        for u in np.linspace(-3.35,3.35,7):
            xb=cx+side*3.48
            b.box((.34,.62,.30),(xb,cy+u,3.47),'red2')
            b.box((.22,.88,.16),(xb-side*.20,cy+u,3.30),'dark')
            b.box((.38,.42,.14),(xb+side*.18,cy+u,3.62),'green_metal')
            b.box((.42,.25,.12),(xb+side*.30,cy+u,3.72),'gold')
    # decorative upper-storey painted bands and bracket blocks
    for side in [-1,1]:
        for u in np.linspace(-1.65,1.65,5):
            yb=cy+side*2.10
            b.box((.46,.24,.24),(cx+u,yb,6.60),'red2')
            b.box((.60,.16,.12),(cx+u,yb-side*.14,6.46),'dark')
            b.box((.30,.26,.11),(cx+u,yb+side*.12,6.73),'gold')
            xb=cx+side*2.10
            b.box((.24,.46,.24),(xb,cy+u,6.60),'red2')
            b.box((.16,.60,.12),(xb-side*.14,cy+u,6.46),'dark')
            b.box((.26,.30,.11),(xb+side*.12,cy+u,6.73),'gold')
    # physical tile ridge lines from roof crowns to the four upturned corners.
    for dx,dy in [(-1,-1),(-1,1),(1,-1),(1,1)]:
        b.cylinder_between((cx,cy,5.38),(cx+dx*4.70,cy+dy*4.70,4.23),.085,'dark',sections=8)
        b.cylinder_between((cx,cy,7.83),(cx+dx*2.85,cy+dy*2.85,6.95),.070,'dark',sections=8)
        # curled gold corner finial/hanger represented by two short articulated rods.
        ex,ey=cx+dx*4.70,cy+dy*4.70
        b.cylinder_between((ex,ey,4.23),(ex+dx*.28,ey+dy*.28,4.52),.050,'gold',sections=8)
        b.cylinder_between((ex+dx*.28,ey+dy*.28,4.52),(ex+dx*.16,ey+dy*.16,4.78),.042,'gold',sections=8)
    # central gold plaque under upper eave
    b.box((2.10,.16,.58),(cx,cy-chamber_half-.10,chamber_z0+1.72),'gold')
    b.box((1.72,.08,.30),(cx,cy-chamber_half-.20,chamber_z0+1.72),'dark')
    # upper roof now sits above the real chamber rather than intersecting it
    pagoda_roof(cx,cy,6.58,2.92,1.26,.38,'tile_red_dark',16,.16)
    for ang in [45,135,225,315]:
        ar=math.radians(ang);b.cylinder_between((cx,cy,7.66),(cx+2.85*math.cos(ar),cy+2.85*math.sin(ar),7.00),.065,'gold',sections=6)
    b.cyl(.12,1.48,(cx,cy,8.32),'gold',sections=12);b.sphere(.20,(cx,cy,9.08),'gold',subdivisions=2)
    # lower-roof underside rafters / beams
    for ang in np.linspace(0,360,16,endpoint=False):
        ar=math.radians(ang);b.cylinder_between((cx,cy,4.08),(cx+4.15*math.cos(ar),cy+4.15*math.sin(ar),3.82),.060,'dark',sections=6)
    for d in [-2.7,-1.8,-.9,0,.9,1.8,2.7]:
        b.box((6.6,.11,.11),(cx,cy+d,3.91),'gold');b.box((.11,6.6,.11),(cx+d,cy,3.90),'gold')
    b.cyl(.78,.18,(cx,cy,3.78),'dome_dark',sections=24);b.cyl(.36,.24,(cx,cy,3.62),'gold',sections=20)
    # lower railings
    for dx in [-3.25,3.25]:
      for yy in np.linspace(-2.7,2.7,6):b.box((.13,.13,.85),(cx+dx,cy+yy,.92),'red2')
    for dy in [-3.25,3.25]:
      for xx in np.linspace(-2.7,2.7,6):b.box((.13,.13,.85),(cx+xx,cy+dy,.92),'red2')
pavilion(-101,-96)
# second source-visible pavilion north-west of the table-tennis courts
pavilion(-101,18)

def add_bamboo_cluster(cx,cy,seed=1,scale=1.0):
    rng=np.random.default_rng(seed)
    for i in range(14):
        x=cx+rng.uniform(-2.4,2.4); y=cy+rng.uniform(-2.0,2.0); hh=rng.uniform(5.8,8.8)*scale
        leanx=rng.uniform(-.45,.45)*scale; leany=rng.uniform(-.45,.45)*scale
        b.cylinder_between((x,y,.10),(x+leanx,y+leany,hh),.045*scale,'green_metal',sections=8)
        # articulated node rings and geometry leaf blades concentrated on upper half
        for zz in np.linspace(hh*.45,hh*.92,5):
            t=zz/hh; sx=x+leanx*t; sy=y+leany*t
            b.cyl(.062*scale,.045,(sx,sy,zz),'gold',sections=8)
            for j in range(3):
                ang=rng.uniform(0,360); ar=math.radians(ang); rr=rng.uniform(.35,.75)*scale
                lx=sx+math.cos(ar)*rr; ly=sy+math.sin(ar)*rr
                b.box((.82*scale,.10*scale,.035*scale),(lx,ly,zz+rng.uniform(-.15,.20)),'tree_leaf3',rotz=ang,rotx=rng.uniform(-25,25))
for k,(bx,by) in enumerate([(-94,-90),(-108,-88),(-93,-103),(-108,-104),(-94,24),(-109,25)]):
    add_bamboo_cluster(bx,by,seed=310+k,scale=.95 if k<4 else .85)

# Table-tennis garden immediately west of the crescent. Registered near-vertical view shows
# four SEPARATE pale slabs in a 2x2 arrangement with a clear east-west road/gap between rows.
# Registered centers from the near-nadir segment_02.5 mosaic: two narrow slabs per row, not four building-sized pads.
for cy_strip in [12.0,-30.5]:
    for cx_strip in [-89.0,-64.0]:
        slab_w,slab_l=7.2,24.2
        b.extrude(Polygon([(cx_strip-slab_w/2,cy_strip-slab_l/2),(cx_strip+slab_w/2,cy_strip-slab_l/2),(cx_strip+slab_w/2,cy_strip+slab_l/2),(cx_strip-slab_w/2,cy_strip+slab_l/2)]),.075,.05,'plaza_light')
        # segment_09 16.4 s resolves six full tables on a single slab; V173's four-table proxy was under-counted.
        for yy in np.linspace(cy_strip-9.2,cy_strip+9.2,6):
            b.box((2.62,1.46,.10),(cx_strip,yy,.86),'blue')
            # red center net/support seen in the source, modeled as solids.
            b.box((.10,1.34,.22),(cx_strip,yy,1.02),'red2')
            for dx in [-.98,.98]: b.box((.15,.15,.78),(cx_strip+dx,yy,.42),'metal')
# clipped hedge borders follow the actual four narrow pads and leave the central road open.
for xh in [-94.0,-76.5,-58.5]: b.box((.72,58.0,.82),(xh,-9.0,.49),'tree_leaf')
for yy in [-43.5,-9.0,25.5]: b.box((39.0,.75,.82),(-76.5,yy,.49),'tree_leaf2')

# North-east paved courtyard in f33 is NOT another table-tennis court: it is a formal plaza with
# square planting beds arranged around a central walk. Replace the old blue-table proxy with planters.
b.extrude(Polygon([(5,97),(63,97),(63,132),(5,132)]),.08,.05,'path_light')
for x in [16,34,52]:
    for y in [104,115,126]:
        b.extrude(Polygon([(x-3.2,y-2.6),(x+3.2,y-2.6),(x+3.2,y+2.6),(x-3.2,y+2.6)]),.20,.08,'path')
        if (int(x+y)//2)%2==0: add_tree(x,y,.62,(int(x)+int(y))%3)
        else:
            for dx,dy in [(-1.5,-.8),(1.4,.6),(0,1.4)]: add_shrub(x+dx,y+dy,.42)

# ---------------- Basketball complex ----------------
def court_lines(cx,cy,L=40,W=20):
    # one complete physical court: boundary, half-court, center circle, keys and green hoops
    for y in [-W/2,W/2]: b.box((L,.10,.025),(cx,cy+y,.19),'court_line')
    for x in [-L/2,L/2,0]: b.box((.10,W,.025),(cx+x,cy,.19),'court_line')
    m=trimesh.creation.annulus(r_min=2.15,r_max=2.27,height=.03,sections=48);m.apply_translation((cx,cy,.19));b.add(m,'court_line')
    # key rectangles and semicircle proxies, physical strips
    for side in [-1,1]:
        kx=cx+side*(L/2-5.0)
        b.box((.10,6.2,.025),(cx+side*(L/2-8.2),cy,.19),'court_line')
        for yy in [cy-3.1,cy+3.1]: b.box((6.8,.10,.025),(cx+side*(L/2-4.8),yy,.19),'court_line')
        hx=cx+side*(L/2-2.0)
        b.cyl(.12,3.25,(hx,cy,1.72),'green_metal',sections=12)
        b.cylinder_between((hx,cy,3.15),(hx-side*.80,cy,3.15),.075,'green_metal',sections=8)
        b.box((.12,1.86,1.08),(hx-side*.84,cy,3.05),'glass')
        # rim ring oriented vertically enough to read in aerial and oblique views
        b.cyl(.46,.06,(hx-side*1.23,cy,2.93),'red2',sections=24,roty=90)

# Footage s03_8: a broad pale concrete slab, 4 columns x 2 rows, directly against south straight of the running track.
# access road immediately south of the basketball fence.
b.extrude(Polygon([(-90,170),(112,170),(112,180),(-90,180)]),.07,.01,'road')
bb_x0,bb_x1,bb_y0,bb_y1=-72,100,182,228
b.extrude(Polygon([(bb_x0,bb_y0),(bb_x1,bb_y0),(bb_x1,bb_y1),(bb_x0,bb_y1)]),.08,.06,'court')
# physical expansion joints in the concrete, no texture
for x in np.linspace(bb_x0+8,bb_x1-8,9): b.box((.045,bb_y1-bb_y0,.014),(x,(bb_y0+bb_y1)/2,.165),'court_joint')
for y in np.linspace(bb_y0+7,bb_y1-7,5): b.box((bb_x1-bb_x0,.045,.014),((bb_x0+bb_x1)/2,y,.165),'court_joint')
# segment_02.5 t37.6 shows three basketball courts per row (3x2), plus a distinct two-court
# volleyball/tennis-marked strip at the east end.  V168's fourth basketball column was wrong.
xs=[-50.5,-8.0,34.5]; ys_c=[193.5,216.0]
for yy in ys_c:
    for xx in xs: court_lines(xx,yy,40.5,20.5)

def volley_lines(cx,cy,L=34.0,W=17.5):
    for y in [-W/2,W/2,0]: b.box((L,.085,.022),(cx,cy+y,.19),'court_line')
    for x in [-L/2,L/2,0]: b.box((.085,W,.022),(cx+x,cy,.19),'court_line')
    # source-visible service/attack lines; no basketball hoops in this eastern strip
    for x in [-6.0,6.0]: b.box((.07,W,.022),(cx+x,cy,.19),'court_line')
    for sx in [-1,1]:
        px=cx+sx*.10; b.box((.10,.10,2.45),(px,cy-W/2-.55,1.35),'green_metal')
        b.box((.10,.10,2.45),(px,cy+W/2+.55,1.35),'green_metal')
    b.box((.055,W,.055),(cx,cy,2.35),'court_line')
for yy in ys_c: volley_lines(79.5,yy,34.0,17.5)
# tall white/metal perimeter fence and dark-green stadium-side fence line
for x in np.linspace(bb_x0,bb_x1,58):
    for yy in [bb_y0,bb_y1]: b.box((.09,.09,3.0),(x,yy,1.55),'curb')
for y in np.linspace(bb_y0,bb_y1,22):
    for xx in [bb_x0,bb_x1]: b.box((.09,.09,3.0),(xx,y,1.55),'curb')
for yy in [bb_y0,bb_y1]:
    b.box((bb_x1-bb_x0,.08,.08),((bb_x0+bb_x1)/2,yy,1.1),'curb');b.box((bb_x1-bb_x0,.08,.08),((bb_x0+bb_x1)/2,yy,2.75),'curb')
for xx in [bb_x0,bb_x1]:
    b.box((.08,bb_y1-bb_y0,.08),(xx,(bb_y0+bb_y1)/2,1.1),'curb');b.box((.08,bb_y1-bb_y0,.08),(xx,(bb_y0+bb_y1)/2,2.75),'curb')
# dark green stadium-side fence layer seen in the overhead footage.
for x in np.linspace(bb_x0,bb_x1,72): b.box((.08,.08,3.4),(x,bb_y1,1.75),'green_metal')
b.box((bb_x1-bb_x0,.08,.08),((bb_x0+bb_x1)/2,bb_y1,3.35),'green_metal')
# teal-green apron strip between basketball fence and red running track as seen overhead
b.extrude(Polygon([(-79,228), (107,228),(107,234),(-79,234)]),.06,.05,'track_apron')

# red-gable low service building beside the basketball/stadium zone visible in s03_4.
b.box((28,12,7.2),(-82,239,3.65),'white'); gable_roof(-82,239,30,14,7.25,0,'red2',4.5)
for xx in np.linspace(-92,-72,6): b.box((1.5,.18,1.45),(xx,232.9,3.8),'window_dark')

# ---------------- Athletic field / stadium ----------------
# Rebuilt as a true capsule track (straightaways + semicircular ends) matching the overhead field footage.
cx,cy=15,265
outer=LineString([(cx-52,cy),(cx+52,cy)]).buffer(38,cap_style=1,resolution=48)
inner=LineString([(cx-52,cy),(cx+52,cy)]).buffer(29.5,cap_style=1,resolution=48)
b.extrude(outer.difference(inner),.10,.02,'track')
# lane dividers as concentric capsule curves
for j in range(1,6):
    lane=LineString([(cx-52,cy),(cx+52,cy)]).buffer(38-j*1.42,cap_style=1,resolution=48).boundary.buffer(.055)
    b.extrude(lane,.025,.145,'court_line')
# rectangular football turf within the track
field_poly=Polygon([(cx-51,cy-28.5),(cx+51,cy-28.5),(cx+51,cy+28.5),(cx-51,cy+28.5)])
b.extrude(field_poly,.08,.08,'field')
# alternating mow/turf bands visible in the near-vertical stadium footage; real thin geometry, no image map.
for i,x0 in enumerate(np.linspace(cx-51,cx+51,13)[:-1]):
    x1=np.linspace(cx-51,cx+51,13)[i+1]
    if i%2==0:
        b.extrude(Polygon([(x0,cy-28.5),(x1,cy-28.5),(x1,cy+28.5),(x0,cy+28.5)]),.012,.165,'field2')
# pitch markings as physical white strips
for y in [cy-28.0,cy,cy+28.0]:b.box((102,.10,.025),(cx,y,.20),'court_line')
for x in [cx-51,cx,cx+51]:b.box((.10,56,.025),(x,cy,.20),'court_line')
# penalty/goal areas and center circle
for side in [-1,1]:
    gx=cx+side*50.5;b.box((.10,18,.025),(gx,cy,.20),'court_line')
    px=cx+side*39.5;b.box((.10,34,.025),(px,cy,.20),'court_line')
    for yy in [cy-17,cy+17]:b.box((11,.10,.025),(cx+side*45,yy,.20),'court_line')
    # simple white goals
    postx=cx+side*50.0
    for yy in [cy-3.7,cy+3.7]:b.box((.10,.10,2.45),(postx,yy,1.3),'court_line')
    b.box((.10,7.5,.10),(postx,cy,2.5),'court_line')
m=trimesh.creation.annulus(r_min=7.7,r_max=7.82,height=.025,sections=64);m.apply_translation((cx,cy,.20));b.add(m,'court_line')
# Long stadium terrace reconstructed from segment_04. The source separates a short covered room bay at left
# from the uncovered stepped stand at center/right; do not repeat windows or seats across the whole frontage.
stand_y=307
roofL=48.0; roof_cx=cx-25.0
# low retaining wall along the entire stand frontage
b.box((104,3.0,1.05),(cx,stand_y-2.0,.56),'stadium_pale')
# room/office strip only below the LEFT covered bay
b.box((roofL-2.0,6.2,3.05),(roof_cx,stand_y-1.1,1.57),'stadium_pale')
for xx in [roof_cx-14.5,roof_cx-9.5,roof_cx+1.8,roof_cx+7.0,roof_cx+12.2]:
    b.box((2.1,.22,1.35),(xx,stand_y-4.32,1.62),'glass_silver')
for xx in [roof_cx-4.2,roof_cx+16.0]: b.box((2.1,.24,2.38),(xx,stand_y-4.34,1.45),'window_dark')
# uncovered stepped seating starts at the canopy's right edge and occupies the long center/right portion.
seat_x0=roof_cx+roofL/2+1.0; seat_x1=cx+50.0; seat_cx=(seat_x0+seat_x1)/2; seat_L=seat_x1-seat_x0
for i in range(9):
    b.box((seat_L-i*.55,1.22,.40),(seat_cx+i*.08,stand_y-.20+i*.98,.34+i*.40),'stadium_step')
# two source-visible staircase aisles bound the uncovered seating.
for aisle in [seat_x0+1.2,seat_x1-2.2]:
    for i in range(9): b.box((3.0,1.25,.10),(aisle,stand_y-.20+i*.98,.61+i*.40),'stone')
    for side in [-1,1]: b.cylinder_between((aisle+side*1.30,stand_y-1.0,.9),(aisle+side*1.30,stand_y+8.4,4.35),.055,'metal',sections=6)
# end rails at the uncovered stand edges
for xrail in [seat_x0,seat_x1]: b.box((.10,9.0,1.0),(xrail,stand_y+3.7,3.95),'metal')

# Segment_04 correction: the dark canopy covers only the LEFT third of the long stand.
# Source segment_05 close pass shows a shallow curved/swept dark canopy, not a flat slab.
# Build a thin barrel/shed surface across the 12.2 m depth as real geometry.
_ny=14; _verts=[]; _faces=[]
for j in range(_ny+1):
    t=j/_ny; yy=stand_y-1.0+t*12.2; zz=7.72+1.15*math.sin(math.pi*t*.88)
    for xx in [roof_cx-roofL/2,roof_cx+roofL/2]: _verts.append((xx,yy,zz))
for j in range(_ny):
    a=2*j; c=a+2; _faces.extend([(a,a+1,c+1),(a,c+1,c)])
_can=trimesh.Trimesh(np.asarray(_verts,float),np.asarray(_faces,int),process=False)
b.add(_can,'roof2')
# underside edge beams emphasize the trussed canopy silhouette.
for xx in [roof_cx-roofL/2,roof_cx+roofL/2]:
    for j in range(_ny):
        a=np.array(_verts[2*j if xx<roof_cx else 2*j+1]); c=np.array(_verts[2*(j+1) if xx<roof_cx else 2*(j+1)+1]); b.cylinder_between(a,c,.09,'dark',sections=6)
for x in np.linspace(roof_cx-roofL/2+2.5,roof_cx+roofL/2-2.5,7):
    b.cylinder_between((x,stand_y+.7,3.15),(x,stand_y+4.2,7.82),.14,'dark',sections=8)
    b.cylinder_between((x,stand_y+9.6,3.15),(x,stand_y+5.4,7.82),.14,'dark',sections=8)
# front-edge triangular steel truss under the short canopy.
truss_y=stand_y-.25; topz=7.78; botz=6.50
xs=np.linspace(roof_cx-roofL/2+1,roof_cx+roofL/2-1,11)
for x in xs: b.cylinder_between((x,truss_y,botz),(x,truss_y,topz),.055,'dark',sections=6)
for i in range(len(xs)-1):
    b.cylinder_between((xs[i],truss_y,botz),(xs[i+1],truss_y,topz if i%2==0 else botz),.055,'dark',sections=6)
    b.cylinder_between((xs[i],truss_y,topz),(xs[i+1],truss_y,botz if i%2==0 else topz),.045,'dark',sections=6)
# Source-red banner sits only below the covered bay.
b.box((36,.36,1.38),(roof_cx,stand_y-.72,5.72),'red')
add_bitmap_text_xz('舞钢市一高2019级新生军训汇报表演',stand_y-.92,roof_cx,5.73,32.5,.80,'white',depth=.12,font_px=74,bold=True)

# Stadium-specific backdrop reconstructed from segment_04 instead of generic campus templates.
def add_stadium_gray_block(cx0,cy0,L=56,W=18,h=18.0):
    b.box((L,W,h),(cx0,cy0,h/2+.05),'stadium_gray')
    b.box((L-1.0,W-1.0,.28),(cx0,cy0,h+.20),'roof2')
    front=cy0-W/2-.12
    for fl in range(4):
        z=3.1+fl*3.4
        for xx in np.linspace(cx0-L/2+5,cx0+L/2-5,12):
            b.box((1.30,.20,1.32),(xx,front,z),'glass_silver')
            b.box((.05,.24,1.28),(xx,front-.03,z),'offwhite')
    # source shows a few blank wall zones and small rooftop vents rather than a repetitive red-trim school facade.
    b.box((7.0,.25,9.0),(cx0-19,front-.05,8.0),'stadium_gray')
    roof_clutter((cx0,cy0),L-8,W-5,h+.40,0,seed=1804,count=7)

def add_stadium_open_corridor_block(cx0,cy0,L=50,W=18,h=13.2):
    b.box((L,W,h),(cx0,cy0,h/2+.05),'stadium_gray')
    front=cy0-W/2-.14
    for fl in range(3):
        z=2.6+fl*3.25
        for xx in np.linspace(cx0-L/2+4,cx0+L/2-4,11):
            b.box((1.35,.20,1.35),(xx,front,z),'glass_silver')
            b.box((.05,.24,1.31),(xx,front-.03,z),'offwhite')
    # open top gallery/colonnade clearly visible in the source right building.
    deck_z=h+.28;b.box((L-1.2,W-1.5,.30),(cx0,cy0,deck_z),'offwhite')
    for xx in np.linspace(cx0-L/2+2,cx0+L/2-2,12):
        b.box((.34,.34,3.0),(xx,front+.35,h+1.55),'offwhite')
    b.box((L,.55,.42),(cx0,front+.30,h+3.05),'stadium_pale')
    # chunky end stair tower with high rectangular openings.
    ex=cx0+L/2-3.1;b.box((6.2,W+1.0,h+3.2),(ex,cy0,(h+3.2)/2),'stadium_pale')
    for zz in [4.0,8.0,12.0]: b.box((.20,4.0,1.65),(ex+3.22,cy0,zz),'window_dark',rotz=90)

# V182 Expert-3 stadium correction from continuous segment_04 5.5-8.0 s:
# left = tall closed gray classroom block; center = broad mostly-blank ~5-storey slab; right = open-corridor block.
def add_stadium_left_closed_block(cx0=-78,cy0=335,L=38,W=18,h=22.0):
    b.box((L,W,h),(cx0,cy0,h/2+.05),'stadium_gray')
    b.box((L-1,W-1,.28),(cx0,cy0,h+.18),'roof2')
    front=cy0-W/2-.14
    # six source-visible floor rows, grouped rather than open galleries.
    for fl in range(6):
        z=2.4+fl*3.15
        for xx in np.linspace(cx0-L/2+5,cx0+L/2-5,7):
            b.box((2.45,.20,1.38),(xx,front,z),'glass_silver')
            b.box((.055,.24,1.32),(xx,front-.02,z),'offwhite')
    # projecting stair/core at the far-left silhouette.
    b.box((7.0,W+1.0,h+2.1),(cx0-L/2+3.7,cy0,(h+2.1)/2),'stadium_gray')
    b.box((.22,5.4,h-5.0),(cx0-L/2-.12,cy0,h/2),'window_dark',rotz=90)
    roof_clutter((cx0,cy0),L-8,W-5,h+.4,0,seed=18204,count=5)

def add_stadium_center_blank_block(cx0=-22,cy0=334,L=72,W=18,h=19.2):
    b.box((L,W,h),(cx0,cy0,h/2+.05),'stadium_gray')
    b.box((L-1,W-1,.28),(cx0,cy0,h+.18),'roof2')
    front=cy0-W/2-.14
    # segment_04 center face is dominated by plain gray wall with thin slab joints and only sparse openings.
    for z in [4.1,8.0,11.9,15.8]: b.box((L-.6,.08,.10),(cx0,front-.04,z),'north_gray2')
    for fl,xxs in enumerate([[-39,-9,18],[-33,2,25],[-37,-6,28],[-28,9,31]]):
        z=2.7+fl*3.8
        for xx in xxs: b.box((1.35,.20,1.28),(xx,front,z),'glass_silver')
    # small right-side vertical puncture group visible near the source edge.
    for z in [3.0,6.4,9.8,13.2]:
        for xx in [cx0+24,cx0+29]: b.box((1.0,.20,1.05),(xx,front,z),'window_dark')
    roof_clutter((cx0,cy0),L-10,W-5,h+.4,0,seed=18205,count=5)

add_stadium_center_blank_block(-22,334,72,18,19.2)
add_stadium_left_closed_block(-78,335,38,18,22.0)
add_stadium_open_corridor_block(51,334,58,19,16.2)
# tall poplar belt behind the right-hand stand/building, clearly visible in segment_04 12-16 s.
for i,xx in enumerate(np.linspace(72,156,14)):
    add_poplar(xx,347.0,.96+(i%3)*.06,(i+1)%3)

# V170 expert-3 correction: old generic flanking classroom proxies were not present in segment_04
# and, together with the old y=330/360 'distant' city blocks, created a false wall of buildings behind the stand.
# Only source-specific stadium backdrop masses above are retained.

# ---------------- Landscape population ----------------
rng=np.random.default_rng(93);pos=[]
# garden dense clusters
for _ in range(92):
    x=rng.uniform(-145,-78);y=rng.uniform(-2,86)
    if west.contains(Point(x,y)):pos.append((x,y))
for _ in range(70):pos.append((rng.uniform(-100,-28),rng.uniform(45,105)))
for y in np.linspace(-88,110,20):pos.extend([(-151,y),(130,y)])
for x in np.linspace(-145,126,25):pos.append((x,112))
for _ in range(55):pos.append((rng.uniform(35,105),rng.uniform(-125,-55)))
for _ in range(35):pos.append((rng.uniform(65,135),rng.uniform(-74,28)))
for i,(x,y) in enumerate(pos):
    if x*x+y*y<29*29:continue
    if min(math.hypot(x+101,y+96),math.hypot(x+101,y-18))<7.2:continue
    add_tree(x,y,rng.uniform(.72,1.18),i%3)
# clipped hedges / shrubs along plaza and building edges
for a in np.linspace(0,2*math.pi,24,endpoint=False):
    x,y=31.0*math.cos(a),31.0*math.sin(a);add_shrub(x,y,.70)
for x in np.linspace(-35,35,17):
    add_shrub(x,48,.58);add_shrub(x,92,.58)
# mature north-edge tree belt visible behind the ceremonial circle; intentionally irregular, all geometry.
for i,a in enumerate(np.linspace(58,112,13)):
    ar=math.radians(a); rr=35.0+(i%3)*1.1; add_tree(rr*math.cos(ar),rr*math.sin(ar),.92+0.06*(i%4),i%3)

# additional mature trees at source-visible east and southwest planting belts.
for yy in [-58,-6,72]:
    for i,xx in enumerate(np.linspace(-145,-72,10)): add_tree(xx,yy,.68+(i%3)*.05,(i+1)%3)
for i,(xx,yy) in enumerate([(62,47),(72,51),(82,54),(103,58),(115,54),(121,28),(119,-20),(112,-34),(-62,-32),(-66,-51),(-63,-70)]): add_tree(xx,yy,.86+(i%3)*.07,i%3)


# Source 2 foreground tree frame: large mature trees along the east approach road, geometry-only.
for i,(xx,yy,ss) in enumerate([(31,-40,1.35),(33,-28,1.28),(34,-12,1.30),(33,15,1.16),(27,-50,1.15),(28,12,1.12)]):
    add_tree(xx,yy,ss,(i+1)%3)

# V167 latest-still vegetation species pass: mixed conifers, poplars and willows replace the all-round-crown look.
for i,(xx,yy,ss) in enumerate([(-42,-71,1.00),(-36,-78,.92),(-31,-88,1.05),(-24,-96,.96),(-18,-74,.90),(-52,-96,.88),(-57,-111,.92),(-92,-111,1.05)]):
    add_conifer(xx,yy,ss,i%2)
for i,(xx,yy,ss) in enumerate([(-119,-56,1.02),(-116,-73,1.08),(-111,-88,1.04),(-105,-104,1.00),(-91,-120,.96),(-70,-117,.94)]):
    add_willow(xx,yy,ss,i%3)
# Tall narrow rows appear repeatedly on the campus perimeter and around the science approach.
for i,yy in enumerate(np.linspace(-125,-46,9)):
    add_poplar(105.0,yy,.88+(i%3)*.05,i%3)
for i,xx in enumerate(np.linspace(112,184,11)):
    add_poplar(xx,-35.0,.82+(i%2)*.05,(i+1)%3)
for i,xx in enumerate(np.linspace(-136,-72,9)):
    add_poplar(xx,37.0,.80+(i%3)*.05,i%3)
# Streetlights on the garden road, south teaching approach and science forecourt.
for i,(xx,yy,ang) in enumerate([(-128,-38,0),(-128,-70,0),(-128,-103,0),(-58,-42,180),(-58,-75,180),(-58,-108,180),
                               (-12,-116,90),(20,-116,90),(50,-116,90),(102,-112,90),(102,-86,90),(102,-60,90),
                               (118,-97,0),(137,-97,0),(156,-97,0),(175,-97,0)]):
    add_streetlamp(xx,yy,ang,.96 if i<12 else 1.02)

# lamps around plaza
for a in np.linspace(0,2*math.pi,20,endpoint=False):
    x,y=32.5*math.cos(a),32.5*math.sin(a);b.cyl(.08,4.2,(x,y,2.15),'metal',sections=8);b.sphere(.18,(x,y,4.35),'stone',subdivisions=1)

# ---------------- Banner-building ground-floor portico ----------------
# V167: the old late-stage duplicate portico block had columns at y=-93..-81 while declaring port_y=-64.5,
# producing floating/duplicated entrance geometry. It is intentionally removed; the single source-specific
# annex/portal is modeled together with the banner facade above.

# Segment 10 is a ground-level pass of the SAME central ceremonial circle at the origin.
# V113 duplicated it at (145,-120); V167 removes that false second plaza entirely.

# sparse vehicles seen in the footage, placed on roads / building forecourts.
add_car(-38,-55,18,'car_white',.92)
add_car(43,-96,2,'car_dark',1.0)
add_car(136,-92,92,'car_dark',1.03)
add_car(118,118,0,'car_white',.90)
add_car(-155,15,90,'car_white',.88)
add_car(148,16,90,'car_red',.90)

# ---------------- Export ----------------
scene,stats=b.finalize();scene.metadata={'name':'Campus unified scene V185','units':'meters','textures':0,'source':'geometry-only reconstruction from 9 uploaded video segments + 6 supplied comparison stills'}
glb=OUT/'campus_unified_V185.glb';glb.write_bytes(scene.export(file_type='glb'))
raw=glb.read_bytes();magic,ver,ln=struct.unpack_from('<III',raw,0);posi=12;j={}
while posi<len(raw):
    clen,ctype=struct.unpack_from('<II',raw,posi);posi+=8;ch=raw[posi:posi+clen];posi+=clen
    if ctype==0x4E4F534A:j=json.loads(ch.decode('utf-8').rstrip(' \t\r\n\x00'));break
strict={'textures':len(j.get('textures',[])),'images':len(j.get('images',[])),'samplers':len(j.get('samplers',[])),'texcoord_attributes':0,'color_attributes':0}
for mesh in j.get('meshes',[]):
    for p in mesh.get('primitives',[]):
        at=p.get('attributes',{});strict['texcoord_attributes']+=sum(1 for q in at if q.startswith('TEXCOORD'));strict['color_attributes']+=sum(1 for q in at if q.startswith('COLOR'))
(OUT/'zero_texture_check_V185.json').write_text(json.dumps(strict,indent=2),encoding='utf-8')
summary={'scene_file':glb.name,'material_groups':len(stats),'parts_before_merge':sum(v['parts'] for v in stats.values()),'vertices':sum(v['vertices'] for v in stats.values()),'faces':sum(v['faces'] for v in stats.values()),'features':['stepped flagpole monument instead of prior fountain proxy','registered shallow faceted crescent administration building immediately west of the single ceremonial circle, with source-like glass towers, gabled atrium and entrance colonnade','source-like east science wing with reduced near-spherical roof dome, central glass gable and four-column gateway aligned to the relocated forecourt/main gate axis','false duplicate ceremonial court removed; segment 10 is unified with the main circle at the origin','geometry-only two-storey Chinese pavilions with dark tile roofs, dougong bracket clusters, ridge finials, lattice chamber and adjacent bamboo geometry','source-traced irregular branching west-garden path network plus four source-matched table-tennis slabs arranged 2x2','five registered north teaching buildings with two source-confirmed L returns; three source-confirmed parallel south teaching bars with three independent D-shaped rounded south end wings and three source-corrected circle-facing terminal headhouses, plus the separately spaced east science/observatory wing and its resized low brown-roof forecourt annex','source-topology northeast auditorium rebuilt as two interlocking irregular roof plates around a concave court, with local pyramidal glass atrium, south-edge red auditorium wing and service annex','source-corrected 3x2 basketball complex plus two distinct eastern volleyball/tennis courts, concrete joints and perimeter fence','capsule running track, football markings, stepped terrace and central truss-roof grandstand','modeled AC condensers, relief brick courses, latest-still red teaching-block piers/banner, admin glass-block lobby bays, broad source-matched plaza apron, higher-resolution branched mature trees and multi-lobed shrubs, corrected admin stair-tower/canopy proportions, reduced source-scale geodesic dome, physical cross-mullioned facade windows, geometry puddles, source-readable raised physical banner lettering with edited-video overlay text explicitly excluded, roof repairs/vents, external galleries, source-localized banner-building ground-floor recessed portico updated to the latest-remodeled facade state, block-by-block plaza paving, raised curbs, physical drain grates, road repair seams and vehicles','zero UV textures, zero images, zero samplers, zero TEXCOORD/COLOR attributes']}
(OUT/'model_stats_V185.json').write_text(json.dumps({'summary':summary,'groups':stats},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2));print('STRICT',strict)
